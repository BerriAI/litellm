def my_custom_rule(input):  # receives the model response
    # if len(input) < 5: # trigger fallback if the model response is too short
    return False
    return True
