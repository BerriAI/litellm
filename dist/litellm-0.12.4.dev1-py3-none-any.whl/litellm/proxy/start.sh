#!/bin/bash
python3 proxy_cli.py --config -f ../../secrets_template.toml
python3 proxy_cli.py