#!/bin/bash
python3 proxy_cli.py