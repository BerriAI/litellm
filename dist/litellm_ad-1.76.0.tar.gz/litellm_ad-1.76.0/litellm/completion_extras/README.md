Logic specific for `litellm.completion`. 

Includes:
- Bridge for transforming completion requests to responses api requests