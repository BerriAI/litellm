-- AlterTable
ALTER TABLE "LiteLLM_TeamTable" ADD COLUMN     "soft_budget" DOUBLE PRECISION;

