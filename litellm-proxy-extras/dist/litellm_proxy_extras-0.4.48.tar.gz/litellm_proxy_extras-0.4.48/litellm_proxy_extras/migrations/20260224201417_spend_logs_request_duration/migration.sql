-- AlterTable
ALTER TABLE "LiteLLM_SpendLogs" ADD COLUMN     "request_duration_ms" INTEGER;

