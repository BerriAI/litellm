-- AlterTable
ALTER TABLE "LiteLLM_MCPServerTable" ADD COLUMN     "credentials" JSONB DEFAULT '{}';
