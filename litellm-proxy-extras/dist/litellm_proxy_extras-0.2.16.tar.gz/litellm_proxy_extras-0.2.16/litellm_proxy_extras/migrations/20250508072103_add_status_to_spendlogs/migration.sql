-- AlterTable
ALTER TABLE "LiteLLM_SpendLogs" ADD COLUMN     "status" TEXT;

