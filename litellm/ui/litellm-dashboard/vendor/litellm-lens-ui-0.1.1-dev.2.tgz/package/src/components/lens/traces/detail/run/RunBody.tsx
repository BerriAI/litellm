"use client";

import { type RefObject, useId, useRef, useState } from "react";
import { List } from "lucide-react";
import { useDefaultLayout } from "react-resizable-panels";
import { useResizeObserver } from "usehooks-ts";

import { useShortcut } from "../../../../shared/useShortcut";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "../../../../ui/Resizable";
import { TabsContent } from "../../../../ui/tabs";
import { Button } from "../../../../ui/button";

import type { RunSelection } from "../../routing";
import type { SignalFlag, Trace } from "../../types";
import { SignalEvidence } from "../../ui/SignalEvidence";
import {
  TraceThread,
  type ConversationTracePaging,
} from "../conversation/TraceThread";
import type { useEarlierConversation } from "../conversation/EarlierConversation";
import { DetailPane } from "../span/DetailPane";
import { SpanTree } from "../tree/SpanTree";
import type { TreeLayout } from "../tree/TreeRows";
import { LogsTimeline } from "../../logs/LogsTimeline";
import { useRunTree } from "./useRunTree";

const SPLIT_LAYOUT_ID = "litellm.lens.runSplit";
const SIDE_BY_SIDE_MIN_PX = 640;

interface RunBodyProps {
  trace: Trace;
  accessToken: string;
  selection: RunSelection;
  embedded: boolean;
  stale: boolean;
  conversationPaging: ConversationTracePaging;
  logRange?: { startMs: number; endMs: number };
  live: boolean;
  signal?: SignalFlag;
  earlierConversation: ReturnType<typeof useEarlierConversation>;
}

/** Tree + detail pane for one loaded run. Arrows move and fold steps; J/K also move unless the drawer owns them. */
export function RunBody({
  trace,
  accessToken,
  selection,
  embedded,
  stale,
  conversationPaging,
  logRange,
  live,
  signal,
  earlierConversation,
}: RunBodyProps) {
  const { view, setView, stepQuery, setStepQuery, errorsOnly, setErrorsOnly } =
    selection;
  const tree = useRunTree(trace, selection);
  const evidence = signal?.evidence;
  const [detailOpen, setDetailOpen] = useState(true);
  const [showLogs, setShowLogs] = useState(false);
  const logsId = useId();
  const [layout, setLayout] = useState<TreeLayout>("tree");
  const splitRef = useRef<HTMLDivElement>(null);
  const { width = SIDE_BY_SIDE_MIN_PX } = useResizeObserver({
    ref: splitRef as RefObject<HTMLDivElement>,
  });
  const orientation = width >= SIDE_BY_SIDE_MIN_PX ? "horizontal" : "vertical";
  const saved = useDefaultLayout({
    id: `${SPLIT_LAYOUT_ID}.${orientation}`,
    panelIds: ["steps", "detail"],
  });
  const select = (id: string) => {
    tree.select(id);
    setDetailOpen(true);
  };

  const active = !stale && view === "steps";
  const pane = { layer: "pane", enabled: active } as const;
  useShortcut("down", () => tree.moveBy(1), { ...pane, description: "step" });
  useShortcut("up", () => tree.moveBy(-1), { ...pane, description: "step" });
  useShortcut("j", () => tree.moveBy(1), {
    ...pane,
    enabled: active && !embedded,
    description: "move",
  });
  useShortcut("k", () => tree.moveBy(-1), {
    ...pane,
    enabled: active && !embedded,
    description: "move",
  });
  useShortcut("left", () => tree.fold(false), { ...pane, description: "fold" });
  useShortcut("right", () => tree.fold(true), { ...pane, description: "fold" });
  useShortcut("escape", () => setDetailOpen(false), {
    ...pane,
    enabled: active && detailOpen,
    description: "close",
  });

  const openStep = (id: string) => {
    select(id);
    setView("steps");
  };

  if (view === "thread")
    return (
      <TabsContent value="thread" className="flex min-h-0 flex-1">
        <TraceThread
          trace={trace}
          accessToken={accessToken}
          paging={conversationPaging}
          onOpenStep={openStep}
          earlierConversation={earlierConversation}
        />
      </TabsContent>
    );

  return (
    <TabsContent
      value="steps"
      ref={splitRef}
      className="flex min-h-0 flex-1 flex-col"
    >
      {logRange && (
        <div className="shrink-0 border-b">
          <Button
            variant="ghost"
            size="sm"
            className="m-1 h-7 gap-1.5 px-2 text-xs text-muted-foreground"
            aria-expanded={showLogs}
            aria-controls={logsId}
            onClick={() => setShowLogs(!showLogs)}
          >
            <List className="size-3.5" />
            {showLogs ? "Hide trace log events" : "Show trace log events"}
          </Button>
          <div id={logsId} hidden={!showLogs}>
            {showLogs && (
              <LogsTimeline
                key={`${trace.summary.trace_id}:${logRange.startMs}:${logRange.endMs}`}
                accessToken={accessToken}
                enabled
                live={live}
                range={logRange}
                traceId={trace.summary.trace_id}
              />
            )}
          </div>
        </div>
      )}
      <ResizablePanelGroup
        key={orientation}
        orientation={orientation}
        className="min-h-0 flex-1"
        defaultLayout={detailOpen ? saved.defaultLayout : undefined}
        onLayoutChanged={detailOpen ? saved.onLayoutChanged : undefined}
      >
        <ResizablePanel
          id="steps"
          defaultSize="40%"
          minSize={orientation === "horizontal" ? 300 : 160}
          maxSize="65%"
        >
          <SpanTree
            rows={tree.rows}
            summary={trace.summary}
            selectedId={tree.selectedId}
            layout={layout}
            onLayoutChange={setLayout}
            hideFramework={tree.hideFramework}
            onSelect={select}
            onToggleHideFramework={tree.setHideFramework}
            onToggleSpan={tree.toggleSpan}
            onToggleGroup={tree.toggleGroup}
            onLoadMore={tree.loadMore}
            onOpenDetails={detailOpen ? undefined : () => setDetailOpen(true)}
            query={stepQuery}
            onQueryChange={setStepQuery}
            errorsOnly={errorsOnly}
            onErrorsOnlyChange={setErrorsOnly}
            filtering={tree.filtering}
            onClearFilters={() => {
              setStepQuery("");
              setErrorsOnly(false);
            }}
            onCollapseAll={tree.collapseAll}
          />
        </ResizablePanel>
        {detailOpen && (
          <>
            <ResizableHandle
              withHandle
              className="bg-border hover:bg-trace-chain"
            />
            <ResizablePanel
              id="detail"
              minSize={orientation === "horizontal" ? 360 : 200}
              className="min-w-0"
            >
              <div className="flex h-full min-h-0 flex-col">
                {signal &&
                  evidence &&
                  evidence.span_id === tree.selectedRow?.id && (
                    <SignalEvidence
                      name={signal.name}
                      quote={evidence.quote}
                      onDismiss={() => selection.selectSpan(evidence.span_id)}
                    />
                  )}
                <div className="min-h-0 flex-1">
                  <DetailPane
                    trace={trace}
                    row={tree.selectedRow}
                    accessToken={accessToken}
                    spanTab={selection.spanTab}
                    onSpanTabChange={selection.setSpanTab}
                    onClose={() => setDetailOpen(false)}
                  />
                </div>
              </div>
            </ResizablePanel>
          </>
        )}
      </ResizablePanelGroup>
    </TabsContent>
  );
}
