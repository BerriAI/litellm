"use client";

import { createContext, useContext, useMemo, type ReactNode } from "react";
import { apiClient } from "../../../lib/http/requests";
import { fetchClient } from "../../../lib/http/api";
import { liveTracesApi, TracesApiContext, type TracesApi } from "../traces/api";
import { liveLensApi, type LensApi } from "./service";
import { liveProfilesApi, type ProfilesApi } from "../profiles/api";
import type { OptimizationStore } from "./demo/demoOptimizations";
import { liveOptimizationStore } from "../optimizations/live";

export interface LensServices {
  readonly accessToken: string;
  readonly lens: LensApi;
  readonly traces: TracesApi;
  readonly profiles: ProfilesApi;
  readonly optimizations?: OptimizationStore;
}

const LensServicesContext = createContext<LensServices | null>(null);

export function liveLensServices(accessToken: string): LensServices {
  return {
    accessToken,
    lens: liveLensApi(fetchClient, apiClient, accessToken),
    traces: liveTracesApi(accessToken),
    profiles: liveProfilesApi(accessToken),
    optimizations: liveOptimizationStore(accessToken),
  };
}

function useLensServices(): LensServices {
  const provided = useContext(LensServicesContext);
  if (!provided) throw new Error("Lens services need a LensServicesProvider above them");
  return provided;
}

export const useLensApi = (): LensApi => useLensServices().lens;

export const useOptionalLensApi = (): LensApi | null => useContext(LensServicesContext)?.lens ?? null;

export const useLensAccessToken = (): string => useLensServices().accessToken;
export const useProfilesApi = (): ProfilesApi => useLensServices().profiles;
export const useOptimizationStore = () => useLensServices().optimizations;

export function useLiveLensServices(accessToken: string): LensServices {
  return useMemo(() => liveLensServices(accessToken), [accessToken]);
}

export function LensServicesProvider({ services, children }: { services: LensServices; children: ReactNode }) {
  return (
    <LensServicesContext.Provider value={services}>
      <TracesApiContext.Provider value={services.traces}>{children}</TracesApiContext.Provider>
    </LensServicesContext.Provider>
  );
}
