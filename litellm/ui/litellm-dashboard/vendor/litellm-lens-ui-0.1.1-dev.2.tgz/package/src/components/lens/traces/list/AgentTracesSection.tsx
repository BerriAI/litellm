"use client";

import moment from "moment";
import { skipToken, useQuery } from "@tanstack/react-query";
import {
  ChartNoAxesColumn,
  ChartPie,
  ChevronDown,
  ChevronUp,
  List,
  RefreshCw,
  X,
} from "lucide-react";
import { traceAgentNames } from "../utils";
import { useId, useMemo, useState } from "react";

import { filterRuns } from "./runSearch/runQuery";
import { RunsToolbar } from "./runSearch/RunsToolbar";
import { Inspector } from "../../../shared/Inspector";
import { Button } from "../../../ui/button";

import { AgentTracesTable } from "./AgentTracesTable";
import { useTraceFindings } from "./useTraceFindings";
import { useTraceFeedback } from "./useTraceFeedback";
import { useTraceSignals } from "./useTraceSignals";
import { useOptionalLensApi } from "../../data/LensServices";
import { lensKeys } from "../../data/queries";
import { signalsConfigured } from "../../model/signals";
import {
  type TraceRef,
  traceKey,
  traceRefOf,
  useOpenTraceRouting,
  useRunFilterRouting,
} from "../routing";
import type { TraceSummary } from "../types";
import { RunView } from "../detail/run/RunView";
import { useZoomRouting } from "../../../shared/timeRange/routing";
import {
  isLive,
  type RelativeRange,
  type TimeWindow,
  timeWindow,
} from "../../../shared/timeRange/timeRange";
import { TimeRangeControls } from "../../../shared/timeRange/TimeRangeControls";
import type { RelativeRangeState } from "../../../shared/timeRange/useRelativeRange";
import { TracesTimeline } from "./TracesTimeline";
import { LogsTimeline } from "../logs/LogsTimeline";
import { useLogTimelineRouting } from "../logs/routing";
import { TracingSetupCard } from "../../onboarding/tracing/TracingSetupCard";
import { useTracesLive } from "../api";
import {
  type AgentTracesResult,
  useAgentTraces,
  useTraceAvailability,
} from "./useAgentTraces";
import { WaitingForTraces } from "../../onboarding/WaitingForTraces";
import styles from "../TraceAppearance.module.css";
import { useLensRoute } from "../../route";

const DRAWER_WIDTH_KEY = "litellm.agentTraces.drawerWidth";

const filterByWindow = (
  runs: TraceSummary[],
  range: TimeWindow,
): TraceSummary[] =>
  runs.filter((run) => {
    const t = moment(run.start_time).valueOf();
    return t >= range.startMs && t < range.endMs;
  });

interface AgentTracesSectionProps {
  accessToken: string;
  isActive: boolean;
  range: RelativeRange;
  /** Page-owned time range + live state; when given, the toolbar shows the range / Live control group. */
  timeControls?: RelativeRangeState;
  readOnly?: boolean;
  canMintTracingKey?: boolean;
  canViewFindings?: boolean;
  onSetUpSignals?: () => void;
  onConnectAgent?: () => void;
}

function useSignalSetup(enabled: boolean) {
  const api = useOptionalLensApi();
  const config = useQuery({
    queryKey: lensKeys.signalConfig(api?.scope ?? ""),
    queryFn: api && enabled ? () => api.signalConfig() : skipToken,
    staleTime: 5000,
  });
  const loaded = enabled && config.data !== undefined;
  return {
    on: loaded && signalsConfigured(config.data),
    missing: loaded && !signalsConfigured(config.data),
  };
}

function useTracingSetup(
  traces: AgentTracesResult,
  isActive: boolean,
  rangeChanged: boolean,
) {
  const [setupResult, setSetupResult] = useState<{
    detail: string | null;
  } | null>(null);
  const waitingForFirstTrace = traces.traces.length === 0 && !rangeChanged;
  const settledResponse = isActive && !traces.isFetching && !traces.error;
  const rememberSetup = waitingForFirstTrace || setupResult !== null;
  if (
    settledResponse &&
    rememberSetup &&
    setupResult?.detail !== traces.notEnabledDetail
  ) {
    setSetupResult({ detail: traces.notEnabledDetail });
  }

  const disabledDetail =
    traces.notEnabledDetail ?? (traces.isFetching ? setupResult?.detail : null);
  const loadingFirstPage = traces.isLoading && setupResult === null;
  const isEmpty =
    !loadingFirstPage && !traces.error && traces.traces.length === 0;
  return {
    disabledDetail,
    isEmpty,
    received: setupResult !== null && traces.traces.length > 0,
  };
}

function TraceHistoryError({
  history,
}: {
  history: ReturnType<typeof useTraceAvailability>;
}) {
  if (!history.error) return null;
  return (
    <div
      role="alert"
      className="flex items-center justify-between gap-4 border-b px-3 py-3 text-sm"
    >
      <p>Could not check earlier traces. {history.error.message}</p>
      <Button
        variant="outline"
        size="sm"
        disabled={history.isFetching}
        onClick={() => void history.refetch()}
      >
        Retry trace check
      </Button>
    </div>
  );
}

/** The Runs view: filters and the runs table — or one run, in place, once a row is clicked. */
export function AgentTracesSection({
  accessToken,
  isActive,
  range,
  timeControls,
  readOnly = false,
  canMintTracingKey = false,
  canViewFindings,
  onSetUpSignals,
  onConnectAgent,
}: AgentTracesSectionProps) {
  const live = useTracesLive();
  const route = useLensRoute();
  const {
    trace: openTrace,
    openTrace: openRun,
    openSignal,
    selection,
    fullScreen,
    setFullScreen,
  } = useOpenTraceRouting();
  const { query, setQuery, agent, status } = useRunFilterRouting();
  const [showSetup, setShowSetup] = useState(false);
  const [showActivity, setShowActivity] = useState(true);
  const logRouting = useLogTimelineRouting();
  const activityId = useId();
  const logsId = useId();
  const [zoom, setZoom] = useZoomRouting();
  const [rangeChanged, setRangeChanged] = useState(false);
  const traceQuery = { accessToken, range, enabled: isActive, agent };
  const traces = useAgentTraces(traceQuery);
  const setup = useTracingSetup(traces, isActive, rangeChanged);
  const checkHistory = setup.isEmpty && !rangeChanged;
  const history = useTraceAvailability(
    accessToken,
    isActive && checkHistory && setup.disabledDetail == null,
  );

  const checkTraces = () => {
    traces.refetch();
    if (setup.disabledDetail == null) void history.refetch();
  };

  // A live range ends "now" (the list query uses Date.now() too); round to the minute so the histogram is stable.
  const minuteEndMs = moment().endOf("minute").valueOf();
  const pickedWindow = useMemo(
    () => timeWindow(range, minuteEndMs),
    [range, minuteEndMs],
  );
  // While the previous range's rows stay on screen, describe them with their own window.
  const window =
    traces.isPlaceholder && traces.window ? traces.window : pickedWindow;
  const filtered = useMemo(
    () => filterRuns(traces.traces, query, { agent, status }),
    [traces.traces, query, agent, status],
  );
  const runs = useMemo(
    () => (zoom ? filterByWindow(filtered, zoom) : filtered),
    [filtered, zoom],
  );
  const feedback = useTraceFeedback(accessToken, runs, isActive);
  const runRefs = useMemo(() => runs.map(traceRefOf), [runs]);
  const findings = useTraceFindings(
    accessToken,
    runs,
    isActive,
    canViewFindings,
  );
  const signalSetup = useSignalSetup(isActive && canViewFindings !== false);
  const signals = useTraceSignals(
    accessToken,
    runs,
    isActive && signalSetup.on,
  );

  const changeRange = (hours: number, apply: (hours: number) => void) => {
    setZoom(null);
    logRouting.reset();
    setRangeChanged(true);
    apply(hours);
  };
  const selectZoom = (selection: TimeWindow | null) => {
    logRouting.reset();
    setZoom(selection);
  };

  const openSentTrace = (trace: TraceSummary) => {
    setShowSetup(false);
    setRangeChanged(true);
    checkTraces();
    openRun(traceRefOf(trace));
  };
  const setupProps = {
    accessToken,
    readOnly,
    canMintTracingKey,
    onOpenTrace: openSentTrace,
    onCheck: checkTraces,
    checking: traces.isFetching,
  };

  if (!openTrace && setup.disabledDetail != null)
    return (
      <WaitingForTraces
        detail={setup.disabledDetail}
        onConnect={onConnectAgent}
        onCheck={checkTraces}
        checking={traces.isFetching}
      />
    );
  // Onboarding only on the first, default view; an empty range the user picked keeps its controls.
  if (!openTrace && checkHistory && !history.error && history.data === false)
    return (
      <WaitingForTraces
        onConnect={onConnectAgent}
        onCheck={checkTraces}
        checking={traces.isFetching || history.isFetching}
      />
    );
  if (showSetup) {
    return (
      <div>
        <button
          type="button"
          onClick={() => setShowSetup(false)}
          className="mb-3 text-sm text-muted-foreground hover:text-foreground"
        >
          ← Back to traces
        </button>
        <TracingSetupCard detail={null} connected {...setupProps} />
      </div>
    );
  }

  return (
    <Inspector.Root
      items={runRefs}
      itemKey={traceKey}
      selected={openTrace}
      onSelectedChange={openRun}
      noun="trace"
      storageKey={DRAWER_WIDTH_KEY}
      fullScreen={fullScreen}
      onFullScreenChange={setFullScreen}
    >
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden bg-card">
        {checkHistory && <TraceHistoryError history={history} />}
        <TracesReceived received={setup.received} />
        <Inspector.Panel label="Trace details" testId="run-drawer">
          {(shown: TraceRef) => (
            <RunView
              traceId={shown.traceId}
              traceRef={shown.traceRef}
              selection={selection}
              accessToken={accessToken}
              logRange={zoom ?? window}
              onBack={() => openRun(null)}
              embedded
              showSignals={signalSetup.on}
            />
          )}
        </Inspector.Panel>
        <RunsToolbar
          query={query}
          onQueryChange={setQuery}
          runs={traces.traces}
          range={zoom ?? window}
          busy={traces.isPlaceholder}
        >
          <Button
            variant="ghost"
            size="sm"
            className="rounded-none border-l px-3 text-xs"
            onClick={() => route.setTab("profiles")}
          >
            <ChartPie aria-hidden="true" className="size-3.5" /> Task profiles
          </Button>
          <TracingSetupAction
            available={traces.traces.length > 0}
            live={live}
            onSetup={onConnectAgent ?? (() => setShowSetup(true))}
          />
          <Button
            variant="ghost"
            size="icon-sm"
            className="h-full w-10 shrink-0 rounded-none border-l"
            aria-label="Refresh traces"
            title="Refresh traces"
            disabled={traces.isFetching}
            onClick={checkTraces}
          >
            <RefreshCw className="size-3.5" />
          </Button>
          {timeControls && (
            <TimeRangeControls
              range={range}
              zoom={zoom}
              onHoursChange={(hours) =>
                changeRange(hours, timeControls.setHours)
              }
              showLive={live}
              onLiveChange={timeControls.setLive}
            />
          )}
        </RunsToolbar>
        <div className="flex shrink-0 flex-wrap items-center justify-between gap-x-3 border-b px-3 py-1">
          <TraceCounts runs={filtered} />
          <div className="ml-auto flex items-center gap-2">
            {!showActivity && zoom && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => selectZoom(null)}
                aria-label="Clear time zoom"
              >
                Zoomed <X className="size-3" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1.5 px-2 text-xs text-muted-foreground"
              aria-expanded={showActivity}
              aria-controls={activityId}
              onClick={() => setShowActivity((shown) => !shown)}
            >
              <ChartNoAxesColumn className="size-3.5" />
              {showActivity ? "Hide activity" : "Show activity"}
              {showActivity ? (
                <ChevronUp className="size-3" />
              ) : (
                <ChevronDown className="size-3" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1.5 px-2 text-xs text-muted-foreground"
              aria-expanded={logRouting.open}
              aria-controls={logsId}
              onClick={() => logRouting.setOpen(!logRouting.open)}
            >
              <List className="size-3.5" />
              {logRouting.open ? "Hide log events" : "Show log events"}
            </Button>
          </div>
        </div>
        <div id={activityId} hidden={!showActivity} className="shrink-0">
          <TracesTimeline
            runs={filtered}
            range={window}
            selection={zoom}
            onSelect={selectZoom}
          />
        </div>
        <div id={logsId} hidden={!logRouting.open} className="shrink-0">
          {logRouting.open && (
            <LogsTimeline
              accessToken={accessToken}
              enabled={isActive}
              live={live && isLive(range) && zoom === null}
              range={zoom ?? window}
            />
          )}
        </div>
        <AgentTracesTable
          traces={runs}
          findings={findings}
          feedback={feedback}
          canViewFindings={canViewFindings}
          signals={signals}
          showSignals={signalSetup.on}
          signalsColumn={signalSetup.on || signalSetup.missing}
          onSetUpSignals={onSetUpSignals}
          onOpenSignal={(run, flag) => openSignal(traceRefOf(run), flag)}
          isLoading={traces.isLoading || (checkHistory && history.isLoading)}
          error={traces.error}
          hasMore={traces.hasMore}
          isFetching={traces.isFetching}
          isPlaceholder={traces.isPlaceholder}
          onRetry={traces.hasMore ? traces.loadMore : traces.refetch}
          onLoadMore={traces.loadMore}
          rangeEmpty={traces.traces.length === 0}
          onSetUpTracing={onConnectAgent ?? (() => setShowSetup(true))}
        />
        <TraceFooter runs={runs} hasMore={traces.hasMore} />
      </div>
    </Inspector.Root>
  );
}

function TracesReceived({ received }: { received: boolean }) {
  if (!received) return null;
  return (
    <p
      role="status"
      className="border-b px-3 py-3 text-sm text-emerald-700 dark:text-emerald-400"
    >
      Traces received. Select a run to inspect it.
    </p>
  );
}

function TraceCounts({ runs }: { runs: readonly TraceSummary[] }) {
  return (
    <dl className={styles.counts} aria-label="Loaded trace summary">
      <div>
        <dt>Loaded runs</dt>
        <dd>{runs.length.toLocaleString()}</dd>
      </div>
      <div>
        <dt>Agents</dt>
        <dd>{new Set(runs.flatMap(traceAgentNames)).size.toLocaleString()}</dd>
      </div>
      <div>
        <dt>Recorded steps</dt>
        <dd>
          {runs
            .reduce((total, run) => total + run.span_count, 0)
            .toLocaleString()}
        </dd>
      </div>
    </dl>
  );
}

function TraceFooter({
  runs,
  hasMore,
}: {
  runs: readonly TraceSummary[];
  hasMore: boolean;
}) {
  return (
    <footer className="flex h-8 shrink-0 items-center border-t bg-muted/30 px-3 font-mono text-[11px] text-muted-foreground">
      {runs.length} {runs.length === 1 ? "run" : "runs"}
      {hasMore ? " loaded" : ""}
    </footer>
  );
}

function TracingSetupAction({
  available,
  live,
  onSetup,
}: {
  available: boolean;
  live: boolean;
  onSetup: () => void;
}) {
  if (!available) return null;
  return (
    <Button
      variant="ghost"
      size="sm"
      className="h-full shrink-0 rounded-none border-l px-3 text-xs"
      disabled={!live}
      onClick={onSetup}
    >
      Connect project
    </Button>
  );
}
