/* Generated from schema/lens-worker.v7.json. Run npm run generate:worker-contract. */

/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Capability".
 */
export type Capability = "function_calling" | "vision" | "reasoning" | "structured_output";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "CompatibilityStatus".
 */
export type CompatibilityStatus = "compatible" | "incompatible" | "unknown";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "InvestigatorState".
 */
export type InvestigatorState =
  "starting" | "running" | "scheduled" | "stalled" | "failed" | "daily_limit" | "unavailable";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationJudge".
 */
export type OptimizationJudge = "feedback" | "llm";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationMode".
 */
export type OptimizationMode = "live" | "shadow" | "offline";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationScope".
 */
export type OptimizationScope = "final" | "agent";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationStatus".
 */
export type OptimizationStatus = "running" | "paused" | "completed";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileSource".
 */
export type ProfileSource = "recorded" | "enhanced" | "pending" | "unknown" | "local" | "uncertain" | "unclassified";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TaxonomyStatus".
 */
export type TaxonomyStatus = "discovering" | "draft" | "frozen" | "failed" | "cleared";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TaxonomyTarget".
 */
export type TaxonomyTarget = "draft" | "active";
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TraceSignalStatus".
 */
export type TraceSignalStatus = "unclassified" | "pending" | "classified" | "failed";

export interface LensWorker {
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ActivationRequest".
 */
export interface ActivationRequest {
  agent: string;
  /**
   * Also classify the draft's discovery range, not only runs that start after activation.
   */
  backfill?: boolean;
  revision: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Activity".
 */
export interface Activity {
  execution_ids?: string[];
  finished?: boolean;
  id: string;
  label: string;
  operations?: (
    | "model"
    | "read"
    | "search"
    | "python"
    | "catalog"
    | "review_catalog"
    | "read_reviews"
    | "search_reviews"
    | "history"
    | "checkpoint"
  )[];
  phase: "load" | "review" | "group" | "reconcile" | "investigate";
  started_at: string;
  tool_calls?: ToolCount[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ToolCount".
 */
export interface ToolCount {
  calls: number;
  name:
    | "model"
    | "read"
    | "search"
    | "python"
    | "catalog"
    | "review_catalog"
    | "read_reviews"
    | "search_reviews"
    | "history"
    | "checkpoint";
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "AgentTestCase".
 */
export interface AgentTestCase {
  expected: string;
  input: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Candidate".
 */
export interface Candidate {
  check_id: string;
  execution_ids: string[];
  existing_finding_id?: string | null;
  hypothesis: string;
  kind?: "issue" | "pattern";
  title: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "CatalogEntry".
 */
export interface CatalogEntry {
  characters: number | null;
  execution: Execution;
  partial: boolean;
  spans: [string, string, string, string, number | null, string, string][];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Execution".
 */
export interface Execution {
  id: string;
  metadata?: MetadataFilter[];
  name: string;
  root_seen?: boolean;
  service?: string;
  source: "traces" | "requests";
  span_count: number;
  start_time: string;
  team_id: string;
  trace_id: string;
  trace_ref?: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "MetadataFilter".
 */
export interface MetadataFilter {
  key: string;
  value: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Check".
 */
export interface Check {
  enabled?: boolean;
  id: string;
  instruction: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Checkpoint".
 */
export interface Checkpoint {
  working_notes: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Claim".
 */
export interface Claim {
  findings: Finding[];
  job: Job;
  lens_id: string;
  reviews?: Review[] | null;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Finding".
 */
export interface Finding {
  brief?: IssueBrief | null;
  check_id: string;
  check_ids?: string[];
  description: string;
  /**
   * @minItems 1
   */
  evidence: Evidence[];
  existing_finding_id?: string | null;
  first_seen: string;
  id: string;
  investigation_runs?: string[];
  kind?: "issue" | "pattern";
  last_seen: string;
  limitation?: string;
  merged_finding_ids?: string[];
  occurrences?: string[];
  priority?: "high" | "medium" | "low";
  reason?: string;
  revision: number;
  status?: "open" | "resolved" | "dismissed";
  suggestion?: string;
  title: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "IssueBrief".
 */
export interface IssueBrief {
  problem: string;
  /**
   * @minItems 1
   */
  test_cases: AgentTestCase[];
  user_goal: string;
  what_happened: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Evidence".
 */
export interface Evidence {
  execution_id: string;
  quote: string;
  role?: "support" | "counterexample";
  span_id: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Job".
 */
export interface Job {
  activities?: Activity[];
  assessments?: RunAssessment[];
  attempts?: number;
  cost?: number;
  coverage?: Coverage;
  created_at: string;
  end: string;
  error?: string;
  findings?: Finding[] | null;
  finished_at?: string | null;
  id: string;
  lease_until?: string | null;
  reading?: InFlight[];
  review_versions?: ReviewVersion[];
  reviewed?: number;
  reviews?: Review[];
  revision: number;
  sample?: Sample | null;
  settings: LensSettings;
  stage?: string;
  start: string;
  status?: "queued" | "running" | "completed" | "failed" | "cancelled";
  steps?: Step[];
  trigger?: "schedule" | "manual";
  worker_id?: string | null;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "RunAssessment".
 */
export interface RunAssessment {
  cannot_assess?: boolean;
  execution_id: string;
  issue_checks?: string[];
  pattern_checks?: string[];
}
export interface Coverage {
  candidates?: number;
  eligible?: number;
  failed_tasks?: number;
  grouped_batches?: number;
  grouping_batches?: number;
  inconclusive?: number;
  investigated?: number;
  partial?: number;
  reusable?: number;
  reused?: number;
  screened?: number;
  selected?: number;
  unassessable?: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "InFlight".
 */
export interface InFlight {
  agent: string;
  execution_id: string;
  started_at: string;
  trace_id: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ReviewVersion".
 */
export interface ReviewVersion {
  content_version: string;
  execution_id: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Review".
 */
export interface Review {
  agent: string;
  at: string;
  cannot_assess?: boolean;
  consolidated?: boolean;
  content_version?: string;
  duration_ms: number;
  execution_id: string;
  extraction?: Extraction | null;
  model: string;
  name: string;
  partial?: boolean;
  reasoning?: string;
  reused?: boolean;
  /**
   * @maxItems 8
   */
  spans?: ReviewSpan[];
  tool_calls?: ToolCount[];
  trace_id: string;
  verdicts?: ReviewVerdict[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Extraction".
 */
export interface Extraction {
  cannot_assess?: boolean;
  observations?: Observation[];
  reasoning?: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Observation".
 */
export interface Observation {
  check_id: string;
  evidence?: Evidence[];
  kind?: "issue" | "pattern";
  summary: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ReviewSpan".
 */
export interface ReviewSpan {
  cited?: boolean;
  kind: string;
  name: string;
  preview: string;
  span_id: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ReviewVerdict".
 */
export interface ReviewVerdict {
  check_id: string;
  kind: "issue" | "pattern";
  summary: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Sample".
 */
export interface Sample {
  eligible: number;
  executions: Execution[];
  next_cursor?: string | null;
  next_offset?: number | null;
  selected?: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "LensSettings".
 */
export interface LensSettings {
  agent_name?: string;
  checks?: Check[];
  concurrency?: number;
  context?: string;
  enabled?: boolean;
  execution_ids?: string[];
  filters?: MetadataFilter[];
  interval_minutes?: number;
  lookback_hours?: number;
  model: string;
  monthly_budget?: number;
  name: string;
  profile?: string | null;
  sample_percent?: number;
  sample_size?: number | null;
  service?: string;
  source?: "traces" | "requests" | "both";
  team_id?: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Step".
 */
export interface Step {
  at: string;
  completion_tokens?: number;
  cost?: number;
  kind: "stage" | "model" | "error";
  label: string;
  model?: string;
  prompt_tokens?: number;
  purpose?: string;
}
/**
 * Runs whose start falls in `[start_ms, end_ms)` are classified; an open window has no end.
 *
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ClassificationWindow".
 */
export interface ClassificationWindow {
  end_ms?: number | null;
  start_ms: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Clusters".
 */
export interface Clusters {
  candidates?: Candidate[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Compatibility".
 */
export interface Compatibility {
  column_key: string;
  missing: Capability[];
  profile_id: string;
  status: CompatibilityStatus;
  unknown: Capability[];
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Coverage".
 */
export interface Coverage1 {
  candidates?: number;
  eligible?: number;
  failed_tasks?: number;
  grouped_batches?: number;
  grouping_batches?: number;
  inconclusive?: number;
  investigated?: number;
  partial?: number;
  reusable?: number;
  reused?: number;
  screened?: number;
  selected?: number;
  unassessable?: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryJob".
 */
export interface DiscoveryJob {
  attempts: number;
  end_ms: number;
  job_id: string;
  lease_until?: string | null;
  max_runs: number;
  requested_at: string;
  start_ms: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryModelChoice".
 */
export interface DiscoveryModelChoice {
  classification: string;
  discovery: string;
  embedding: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryModelOptions".
 */
export interface DiscoveryModelOptions {
  classification: string[];
  discovery: string[];
  embedding: string[];
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryPoint".
 */
export interface DiscoveryPoint {
  api_key_hash: string;
  task_id?: string | null;
  team_id: string;
  trace_id: string;
  x: number;
  y: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryPreview".
 */
export interface DiscoveryPreview {
  eligible_runs: number;
  previews: DiscoveryPreviewRun[];
  sample_runs: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryPreviewRun".
 */
export interface DiscoveryPreviewRun {
  input_preview: string;
  start_ms: number;
  trace_id: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryRequest".
 */
export interface DiscoveryRequest {
  agent: string;
  end_ms: number;
  max_runs: number;
  /**
   * Revision of the discovery or draft under review that a new discovery replaces, 0 when
   * none is shown. Previews ignore it.
   */
  revision?: number;
  start_ms: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "DiscoveryRun".
 */
export interface DiscoveryRun {
  end_ms: number;
  requested_runs: number;
  sampled_runs: number;
  start_ms: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "EvidenceReply".
 */
export interface EvidenceReply {
  catalog?: CatalogEntry[];
  error?: string;
  parts?: TracePart[];
  request: EvidenceRequest;
  review_catalog?: ReviewIndex[];
  reviews?: ReviewRecord[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TracePart".
 */
export interface TracePart {
  content: string;
  end_time?: string;
  execution_id: string;
  kind: string;
  name: string;
  parent_span_id?: string;
  span_id: string;
  start_time?: string;
  truncated?: boolean;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "EvidenceRequest".
 */
export interface EvidenceRequest {
  action: "catalog" | "read" | "search" | "review_catalog" | "read_reviews" | "search_reviews" | "history";
  char_end?: number | null;
  char_start?: number;
  execution_id?: string | null;
  include_initial?: boolean;
  query?: string;
  review_phase?: ("initial" | "revisited") | null;
  span_ids?: string[];
  turn_end?: number | null;
  turn_start?: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ReviewIndex".
 */
export interface ReviewIndex {
  characters: number;
  execution_id: string;
  phase: "initial" | "revisited";
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ReviewRecord".
 */
export interface ReviewRecord {
  content: string;
  execution_id: string;
  phase: "initial" | "revisited";
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ExecutionContent".
 */
export interface ExecutionContent {
  execution: Execution;
  next_cursor?: string | null;
  partial?: boolean;
  parts: TracePart[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "FindingDraft".
 */
export interface FindingDraft {
  brief?: IssueBrief | null;
  check_id: string;
  check_ids?: string[];
  description: string;
  /**
   * @minItems 1
   */
  evidence: Evidence[];
  existing_finding_id?: string | null;
  kind?: "issue" | "pattern";
  limitation?: string;
  merged_finding_ids?: string[];
  priority?: "high" | "medium" | "low";
  suggestion?: string;
  title: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "FindingGroup".
 */
export interface FindingGroup {
  /**
   * @minItems 1
   */
  members: string[];
  representative: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "FindingGroups".
 */
export interface FindingGroups {
  groups: FindingGroup[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Findings".
 */
export interface Findings {
  findings?: FindingDraft[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "InvestigatorStatus".
 */
export interface InvestigatorStatus {
  agent_name: string;
  detail: string;
  last_analysis_at?: string | null;
  last_checked_at?: string | null;
  lens_id: string;
  model: string;
  next_run_at?: string | null;
  posts_today: number;
  run_limit: number;
  runs_today: number;
  state: InvestigatorState;
  [k: string]: unknown;
}
/**
 * Where discovery placed one sampled run; runs outside the discovery sample have no position.
 *
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "MapPoint".
 */
export interface MapPoint {
  profile_id: string;
  trace_id: string;
  x: number;
  y: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "MatrixCell".
 */
export interface MatrixCell {
  avg_cost_usd?: number | null;
  column_key: string;
  cost_observations: number;
  eval_sample_count: number;
  eval_success_rate?: number | null;
  latency_observations: number;
  p95_latency_ms?: number | null;
  profile_id: string;
  request_count: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ModelCapabilities".
 */
export interface ModelCapabilities {
  function_calling?: boolean | null;
  reasoning?: boolean | null;
  structured_output?: boolean | null;
  vision?: boolean | null;
  [k: string]: unknown;
}
/**
 * A matrix column. `model_config_id` is the gateway deployment ID recorded on the ledger
 * row, or `None` when no matched ledger row carried one.
 *
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ModelColumn".
 */
export interface ModelColumn {
  capabilities: ModelCapabilities;
  column_key: string;
  configured: boolean;
  model_config_id?: string | null;
  model_group: string;
  model_name: string;
  provider: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ModelMessage".
 */
export interface ModelMessage {
  content: string;
  role: "system" | "user" | "assistant";
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ModelRequest".
 */
export interface ModelRequest {
  messages?: ModelMessage[];
  prompt: string;
  purpose: "extract" | "cluster" | "investigate";
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ModelResult".
 */
export interface ModelResult {
  content: string;
  context_exceeded?: boolean;
  cost: number;
  finish_reason?: ("length" | "content_filter") | null;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationAssignment".
 */
export interface OptimizationAssignment {
  baseline: boolean;
  model: string;
  optimizationId?: string | null;
  traceId: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationConfig".
 */
export interface OptimizationConfig {
  agent: string;
  baseline: string;
  baselineSampling: number;
  candidateSampling: number;
  datasetId: string;
  datasetName: string;
  judge: OptimizationJudge;
  judgeModel: string;
  mode: OptimizationMode;
  models: string[];
  revision: number;
  rubric: string;
  scope: OptimizationScope;
  teamId: string;
  tolerance: number;
  traffic: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationResult".
 */
export interface OptimizationResult {
  completedAt: number;
  costUsd?: number | null;
  durationMs?: number | null;
  error?: string | null;
  expected: string;
  id: string;
  input: string;
  model: string;
  original: string;
  output?: string | null;
  score?: number | null;
  scoreError?: string | null;
  servedModel?: string | null;
  sourceId: string;
  spanId: string;
  traceId: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "OptimizationRun".
 */
export interface OptimizationRun {
  config: OptimizationConfig;
  createdAt: number;
  error?: string | null;
  id: string;
  pending: number;
  results: OptimizationResult[];
  status: OptimizationStatus;
  [k: string]: unknown;
}
/**
 * How much of the window the figures rest on. When `truncated` is set, `runs_listed` is a
 * lower bound and the request, cost and latency figures cover only `runs_resolved` runs.
 *
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileCoverage".
 */
export interface ProfileCoverage {
  runs_listed: number;
  runs_resolved: number;
  truncated: boolean;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileDetail".
 */
export interface ProfileDetail {
  coverage: ProfileCoverage;
  definition?: TaskDefinition | null;
  models: MatrixCell[];
  profile: ProfileSummary;
  runs: ProfileRunRef[];
  window: ProfileWindow;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TaskDefinition".
 */
export interface TaskDefinition {
  description: string;
  example_trace_ids: string[];
  exclusion_criteria: string;
  inclusion_criteria: string;
  name: string;
  /**
   * Deprecated: discovery no longer generates requirements, so new categories leave it empty.
   */
  required_capabilities: Capability[];
  task_id: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileSummary".
 */
export interface ProfileSummary {
  cost_observations: number;
  name: string;
  profile_id: string;
  request_count: number;
  run_count: number;
  share: number;
  source: ProfileSource;
  spend_usd?: number | null;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileRunRef".
 */
export interface ProfileRunRef {
  input_preview: string;
  request_count: number;
  /**
   * False when the span budget ran out before this run was read, so `request_count` and
   * `spend_usd` say nothing about it.
   */
  resolved: boolean;
  spend_usd?: number | null;
  start_ms: number;
  trace_id: string;
  trace_ref: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileWindow".
 */
export interface ProfileWindow {
  agent: string;
  end_ms: number;
  start_ms: number;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileRef".
 */
export interface ProfileRef {
  name: string;
  profile_id: string;
  /**
   * Deprecated: always `None`; categories no longer state model requirements.
   */
  required_capabilities?: Capability[] | null;
  source: ProfileSource;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileSettings".
 */
export interface ProfileSettings {
  agent: string;
  enabled: boolean;
  models: DiscoveryModelChoice;
  revision: number;
  updated_at?: string | null;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileSettingsUpdate".
 */
export interface ProfileSettingsUpdate {
  agent: string;
  enabled: boolean;
  models: DiscoveryModelChoice;
  revision: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileSettingsView".
 */
export interface ProfileSettingsView {
  can_write: boolean;
  defaults: DiscoveryModelChoice;
  options: DiscoveryModelOptions;
  settings: ProfileSettings;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfileTotals".
 */
export interface ProfileTotals {
  cost_observations: number;
  matched_requests: number;
  other_agent_requests: number;
  requests: number;
  runs: number;
  shared_requests: number;
  spend_usd?: number | null;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfilesMatrix".
 */
export interface ProfilesMatrix {
  cells: MatrixCell[];
  /**
   * Deprecated: always empty; requirements are not compared with deployments.
   */
  compatibility: Compatibility[];
  coverage: ProfileCoverage;
  models: ModelColumn[];
  other_agent_requests: number;
  profiles: ProfileRef[];
  window: ProfileWindow;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ProfilesOverview".
 */
export interface ProfilesOverview {
  coverage: ProfileCoverage;
  points: MapPoint[];
  profiles: ProfileSummary[];
  totals: ProfileTotals;
  window: ProfileWindow;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Progress".
 */
export interface Progress {
  activity?: Activity | null;
  coverage?: Coverage1 | null;
  reading?: InFlight[] | null;
  review?: Review | null;
  stage?: string | null;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "PythonAgentTurn[Extraction]".
 */
export interface PythonAgentTurnExtraction {
  checkpoint?: string | null;
  result?: Extraction | null;
  tools?: (EvidenceRequest | PythonRequest)[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "PythonRequest".
 */
export interface PythonRequest {
  action: "python";
  code: string;
  execution_ids?: string[];
  span_ids?: string[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "PythonAgentTurn[Findings]".
 */
export interface PythonAgentTurnFindings {
  checkpoint?: string | null;
  result?: Findings | null;
  tools?: (EvidenceRequest | PythonRequest)[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ReplayRequest".
 */
export interface ReplayRequest {
  messages: unknown[];
  parameters?: {
    [k: string]: unknown;
  };
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "ResetRequest".
 */
export interface ResetRequest {
  agent: string;
  revision: number;
  target?: "draft" | "active";
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Result".
 */
export interface Result {
  assessments?: RunAssessment[];
  coverage: Coverage1;
  error?: string;
  findings?: FindingDraft[];
  review_versions?: ReviewVersion[];
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "SignalAlertDelivery".
 */
export interface SignalAlertDelivery {
  at: string;
  status: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "SignalAlertRequest".
 */
export interface SignalAlertRequest {
  enabled: boolean;
  revision: number;
  signal_ids: string[];
  webhook_url?: string | null;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "SignalAlertTest".
 */
export interface SignalAlertTest {
  webhook_url?: string | null;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "SignalAlertView".
 */
export interface SignalAlertView {
  connected: boolean;
  enabled: boolean;
  last_delivery?: SignalAlertDelivery | null;
  revision: number;
  signal_ids: string[];
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "SignalEvidence".
 */
export interface SignalEvidence {
  quote: string;
  span_id: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "SignalFlag".
 */
export interface SignalFlag {
  evidence?: SignalEvidence | null;
  name: string;
  score: number;
  signal_id: string;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TaskEdit".
 */
export interface TaskEdit {
  agent: string;
  description: string;
  exclusion_criteria: string;
  inclusion_criteria: string;
  name: string;
  /**
   * Deprecated and ignored.
   */
  required_capabilities?: Capability[];
  revision: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "Taxonomy".
 */
export interface Taxonomy {
  agent: string;
  discovered_at?: string | null;
  discovery?: DiscoveryRun | null;
  error?: string | null;
  frozen_at?: string | null;
  job?: DiscoveryJob | null;
  models: TaxonomyModels;
  points: DiscoveryPoint[];
  /**
   * Changes on every write, so a stale browser edit is rejected.
   */
  revision: number;
  status: TaxonomyStatus;
  tasks: TaskDefinition[];
  taxonomy_id: string;
  /**
   * Generation that assignments are keyed by; it only grows, even across resets.
   */
  version: number;
  windows: ClassificationWindow[];
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TaxonomyModels".
 */
export interface TaxonomyModels {
  decision: string;
  distill: string;
  embedding: string;
  synthesis: string;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TaxonomyRevisionRequest".
 */
export interface TaxonomyRevisionRequest {
  agent: string;
  revision: number;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TaxonomyView".
 */
export interface TaxonomyView {
  /**
   * The activated taxonomy that runs resolve against.
   */
  active?: Taxonomy | null;
  can_write: boolean;
  discovery_available: boolean;
  /**
   * The discovery job, draft or failure under review.
   */
  taxonomy?: Taxonomy | null;
  [k: string]: unknown;
}
/**
 * This interface was referenced by `LensWorker`'s JSON-Schema
 * via the `definition` "TraceSignals".
 */
export interface TraceSignals {
  classified_at?: string | null;
  flags?: SignalFlag[];
  model?: string;
  partial?: boolean;
  status: TraceSignalStatus;
  trace_id: string;
  trace_ref?: string;
}
