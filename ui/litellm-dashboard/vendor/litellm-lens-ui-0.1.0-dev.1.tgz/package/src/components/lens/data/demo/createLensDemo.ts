import { ApiError } from "../../../../lib/http/client";
import type { TracesApi } from "../../traces/api";
import { traceAgentNames } from "../../traces/utils";
import { rollUpAgents } from "../../agents/agentRollup";
import type { Feedback, TraceSummary } from "../../traces/types";
import type { LensServices } from "../LensServices";
import type { LensApi } from "../service";
import { demoDatasetsApi } from "./demoDatasets";
import { createLensDemoData, type LensDemoData } from "./fixtures";
import { usageCategory } from "../../profiles/usageProfile";

const notInDemo = (): Promise<never> =>
  Promise.reject(new ApiError("This item is not in the demo", 404, { detail: "This item is not in the demo" }));
const readOnly = (): Promise<never> =>
  Promise.reject(new ApiError("Demo data is read-only", 403, { detail: "Demo data is read-only" }));
const found = <T>(value: T | undefined): Promise<T> => (value === undefined ? notInDemo() : Promise.resolve(value));

function demoLensApi(data: LensDemoData): LensApi {
  const jobs = (lensId: string) => data.lenses.find((lens) => lens.id === lensId)?.jobs;
  return {
    scope: "demo",
    datasets: demoDatasetsApi(data),
    evalRuns: {
      list: async () => [],
      get: notInDemo,
      runCase: notInDemo,
      cases: notInDemo,
      evals: async () => [],
      evalDefinition: notInDemo,
      saveEval: notInDemo,
    },
    lenses: async () => ({ lenses: data.lenses, workers: [], tracing_enabled: true }),
    activity: async () => ({ traces: true, requests: false }),
    runs: (lensId, offset) => found(jobs(lensId)?.slice(offset)),
    run: (lensId, jobId) => found(jobs(lensId)?.find((job) => job.id === jobId)),
    reviews: async (lensId, jobId, after) => {
      const job = await found(jobs(lensId)?.find((item) => item.id === jobId));
      return {
        reviews: job.reviews.slice(Math.max(0, after - (job.reviewed - job.reviews.length))),
        reviewed: job.reviewed,
      };
    },
    execution: notInDemo,
    sample: notInDemo,
    agents: notInDemo,
    models: async () => ({ data: [] }),
    modelDetails: async () => ({ data: [] }),
    gateway: async () => ({
      configured: false,
      connected: false,
      api_base: null,
      analysis_models: 0,
      evaluation_models: 0,
      error: null,
      last_refreshed: null,
    }),
    refreshGateway: readOnly,
    saveLens: readOnly,
    startRun: readOnly,
    watchAll: async () => ({ watching: [], skipped: [] }),
    signalConfig: async () => ({ model: "", threshold: 0.5, signals: [] }),
    saveSignalConfig: readOnly,
    cancelRun: readOnly,
    reviewFinding: readOnly,
  };
}

const DEMO_FEEDBACK = [
  { score: 3, comment: "It edited the wrong file and I had to ask twice.", author: "customer-1042" },
  { score: 9, comment: "Exactly what I asked for.", author: "customer-2210" },
] as const;

function demoFeedback(runs: LensDemoData["runs"]): Feedback[] {
  return DEMO_FEEDBACK.flatMap((entry, index) => {
    const summary: TraceSummary | undefined = runs[index]?.trace.summary;
    if (!summary) return [];
    const at = summary.start_time;
    return [
      { ...entry, trace_id: summary.trace_id, trace_ref: summary.trace_ref ?? "", created_at: at, updated_at: at },
    ];
  });
}

const summariesIn = (data: LensDemoData, startMs: number, endMs: number) =>
  data.runs
    .map((item) => item.trace.summary)
    .filter((trace) => Date.parse(trace.start_time) >= startMs && Date.parse(trace.start_time) <= endMs);

function demoTracesApi(data: LensDemoData): TracesApi {
  const run = (traceId: string) => data.runs.find(({ trace }) => trace.summary.trace_id === traceId);
  const feedback = demoFeedback(data.runs);
  const feedbackFor = (traceId: string) => feedback.filter((entry) => entry.trace_id === traceId);
  return {
    live: false,
    handoff: (traceId, spanId) => {
      const found = run(traceId);
      const step = spanId ? found?.details.find((span) => span.span_id === spanId) : found;
      return { text: JSON.stringify(step, null, 2), copied: spanId ? "Step copied" : "Trace copied" };
    },
    list: async ({ startMs, endMs }, agent) => ({
      data: summariesIn(data, startMs, endMs).filter((trace) => !agent || traceAgentNames(trace).includes(agent)),
      next_cursor: null,
    }),
    agents: async ({ startMs, endMs }) => rollUpAgents(summariesIn(data, startMs, endMs)),
    findings: async (traces) =>
      traces.map((trace) => {
        const jobs = data.lenses.flatMap((lens) => lens.jobs).filter((job) => job.status === "completed");
        const assessed = jobs.flatMap((job) =>
          (job.sample?.executions ?? [])
            .filter((execution) => {
              const matches =
                execution.source === "traces" &&
                execution.trace_id === trace.trace_id &&
                (execution.trace_ref ?? "") === (trace.trace_ref ?? "");
              return (
                matches &&
                job.assessments.some(
                  (assessment) => assessment.execution_id === execution.id && !assessment.cannot_assess,
                )
              );
            })
            .map((execution) => ({ job, execution })),
        );
        const findings = new Set(
          assessed.flatMap(({ job, execution }) =>
            (job.findings ?? [])
              .filter((finding) => finding.occurrences.includes(execution.id))
              .map((finding) => finding.id),
          ),
        );
        return { ...trace, finding_count: assessed.length ? findings.size : null };
      }),
    signals: async (traces) =>
      traces.map((trace) => ({ ...trace, status: "unclassified" as const, flags: [], model: "", classified_at: null })),
    feedbackSummary: async (traces) =>
      traces.map((trace) => {
        const scores = feedbackFor(trace.trace_id).map((entry) => entry.score);
        return {
          trace_id: trace.trace_id,
          trace_ref: trace.trace_ref ?? "",
          count: scores.length,
          average: scores.length ? scores.reduce((sum, score) => sum + score, 0) / scores.length : null,
          lowest: scores.length ? Math.min(...scores) : null,
        };
      }),
    feedback: async (traceId) => {
      const summary = (await found(run(traceId))).trace.summary;
      return { trace_id: traceId, trace_ref: summary.trace_ref ?? "", feedback: feedbackFor(traceId) };
    },
    anyRecorded: async () => data.runs.length > 0,
    trace: (traceId) => found(run(traceId)?.trace),
    conversation: async (traceId) => {
      const current = await found(run(traceId));
      const session = current.details[0]?.attributes["session.id"];
      const earlier = session
        ? data.runs
            .filter(
              (candidate) =>
                candidate.details[0]?.attributes["session.id"] === session &&
                candidate.trace.summary.start_time < current.trace.summary.start_time,
            )
            .toSorted((a, b) => a.trace.summary.start_time.localeCompare(b.trace.summary.start_time))
        : [];
      return {
        turns: earlier.map(({ trace, details }) => ({
          trace_id: trace.summary.trace_id,
          trace_ref: trace.summary.trace_ref ?? "",
          span_id: details[0].span_id,
          start_time: trace.summary.start_time,
          input: details[0].input,
          output: details[0].output,
          input_ui: { kind: "text" as const, text: details[0].input },
          output_ui: { kind: "text" as const, text: details[0].output },
        })),
        next_cursor: null,
      };
    },
    span: (traceId, spanId) => found(run(traceId)?.details.find((span) => span.span_id === spanId)),
    spanError: async (traceId, spanId) => {
      const span = run(traceId)?.trace.spans.find((item) => item.span_id === spanId);
      return found(
        span && {
          span_id: span.span_id,
          message: span.error ?? "",
          total_chars: span.error?.length ?? 0,
          next_cursor: null,
        },
      );
    },
  };
}

export function createLensDemo(now = Date.now()): LensServices {
  const data = createLensDemoData(now);
  return {
    accessToken: "lens-demo",
    lens: demoLensApi(data),
    traces: demoTracesApi(data),
    profiles: {
      scope: "demo",
      usage: async ({ startMs, endMs }, agent) => {
        const counts = new Map<string, number>();
        for (const run of data.runs) {
          const trace = run.trace.summary;
          const at = Date.parse(trace.start_time);
          if (
            at < startMs ||
            at >= endMs ||
            (agent && !traceAgentNames(trace).includes(agent))
          )
            continue;
          const category =
            run.details
              .map((detail) => usageCategory(detail.attributes))
              .find(Boolean) ?? "Unclassified";
          counts.set(category, (counts.get(category) ?? 0) + 1);
        }
        return [...counts]
          .map(([category, runs]) => ({ category, runs }))
          .sort(
            (a, b) => b.runs - a.runs || a.category.localeCompare(b.category),
          );
      },
    },
  };
}
