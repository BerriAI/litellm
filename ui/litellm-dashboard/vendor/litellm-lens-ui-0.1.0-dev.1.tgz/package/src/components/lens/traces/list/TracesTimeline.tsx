"use client";

import moment from "moment";
import { useMemo } from "react";

import type { TimeWindow } from "../../../shared/timeRange/timeRange";
import { Timeline, TIMELINE_BUCKETS, type TimeBucket } from "../../../shared/timeline/Timeline";

import type { TraceSummary } from "../types";
import { traceAgentNames } from "../utils";
import styles from "../TraceAppearance.module.css";

/** Run counts per equal-width time bucket across the window; runs outside it are dropped. */
export function bucketRuns(runs: readonly TraceSummary[], range: TimeWindow, buckets = TIMELINE_BUCKETS): TimeBucket[] {
  const width = (range.endMs - range.startMs) / buckets;
  const placed = runs.map((run) => ({
    index: Math.floor((moment(run.start_time).valueOf() - range.startMs) / width),
    failed: run.status === "error",
    agent: traceAgentNames(run)[0] ?? "",
  }));
  return Array.from({ length: buckets }, (_, i) => {
    const hits = placed.filter((p) => p.index === i);
    return {
      startMs: range.startMs + i * width,
      endMs: range.startMs + (i + 1) * width,
      total: hits.length,
      failed: hits.filter((p) => p.failed).length,
      series: hits.filter((p) => !p.failed).map((p) => p.agent),
    };
  });
}

interface TracesTimelineProps {
  runs: readonly TraceSummary[];
  range: TimeWindow;
  selection: TimeWindow | null;
  onSelect: (selection: TimeWindow | null) => void;
}

/** Lens adapter: buckets the currently loaded runs and hands them to the shared timeline. */
const RUN_NOUN = { singular: "run", plural: "runs" };

export function TracesTimeline({ runs, range, selection, onSelect }: TracesTimelineProps) {
  const buckets = useMemo(() => bucketRuns(runs, range), [runs, range]);
  return (
    <section className={styles.timeline} aria-label="Run activity">
      <div className={styles.timelineLabel}>
        <span className="lens-section-label">Run activity</span>
        <span>Drag to zoom</span>
      </div>
      <Timeline buckets={buckets} selection={selection} onSelect={onSelect} noun={RUN_NOUN} />
    </section>
  );
}
