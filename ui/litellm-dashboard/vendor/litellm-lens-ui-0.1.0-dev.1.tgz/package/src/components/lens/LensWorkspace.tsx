"use client";

import { useEffect, useId, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs } from "@base-ui/react/tabs";
import { BookOpen, ChevronRight, Github, Loader2 } from "lucide-react";
import { useLensHost } from "../../host/LensHost";
import AgentTracesPage from "./traces/list/AgentTracesPage";
import { Button } from "../ui/button";
import type { TraceSummary } from "./traces/types";
import { Switch } from "../ui/switch";
import { TabsContent } from "../ui/tabs";
import { LensServicesProvider, useLensAccessToken, useLensApi, useLiveLensServices } from "./data/LensServices";
import { isProxyAdminRole, isProxyAdminTierRole } from "../../utils/roles";
import { DatasetsView } from "./datasets/DatasetsView";
import { EvalsView } from "./evals/EvalsView";
import { LensSettings } from "./settings/LensSettings";
import { createLensDemo } from "./data/demo/createLensDemo";
import { lensQueries } from "./data/queries";
import { LensSidebar } from "./LensSidebar";
import { LensTabs } from "./LensTabs";
import { FindingsView } from "./investigations/FindingsView";
import { InvestigationsView } from "./investigations/InvestigationsView";
import { investigationActivity, listPollInterval } from "./model/status";
import { cn } from "../../lib/cva.config";
import {
  LENS_TABS,
  useDialogRoute,
  useGitHubRoute,
  useIssueRoute,
  useLensRoute,
  type LensDialog,
  type LensTab,
} from "./route";
import { LensGettingStarted } from "./onboarding/LensGettingStarted";
import { useLensReadiness, type LensReadiness } from "./hooks/useLensReadiness";
import { OnboardingProvider, type Onboarding } from "./onboarding/OnboardingContext";
import { traceRefOf, useOpenTraceRouting, type TraceRef } from "./traces/routing";
import { useLensAgents } from "./agents/AgentScoped";
import { AgentsView } from "./agents/AgentsView";
import { AgentPicker } from "./agents/AgentPicker";
import { ProfilesView } from "./profiles/ProfilesView";
import { LensHome } from "./onboarding/LensHome";
import { AgentGitHubDialog } from "./agents/AgentGitHubDialog";
import { LensPageActionsContext } from "./ui/LensPageHeader";

type WorkspaceProps = {
  accessToken: string;
  userRole: string;
  readOnly: boolean;
};

export function LensWorkspace(props: WorkspaceProps) {
  const { demo } = useLensRoute();
  return demo ? <SampleSession /> : <LiveSession {...props} />;
}

function LiveSession(props: WorkspaceProps) {
  const services = useLiveLensServices(props.accessToken);
  return (
    <LensServicesProvider services={services}>
      <LensContent userRole={props.userRole} readOnly={props.readOnly} />
    </LensServicesProvider>
  );
}

function SampleSession() {
  const [services] = useState(() => createLensDemo());
  return (
    <LensServicesProvider services={services}>
      <LensContent userRole="proxy_admin_viewer" readOnly />
    </LensServicesProvider>
  );
}

function DemoToggle({ demo, onChange }: { demo: boolean; onChange: (demo: boolean) => void }) {
  const id = useId();
  return (
    <div
      className={cn(
        "flex items-center gap-2 whitespace-nowrap text-xs",
        demo ? "font-medium text-info" : "text-muted-foreground",
      )}
    >
      <label htmlFor={id}>Demo data</label>
      <Switch id={id} size="sm" checked={demo} onCheckedChange={onChange} className="data-checked:bg-info" />
    </div>
  );
}

/** The one always-mounted `/lens` observer; every other reader is a plain cache subscriber. */
function useLensOverview(enabled: boolean, settingsOpen: boolean) {
  const api = useLensApi();
  const { data } = useQuery({
    ...lensQueries.list(api),
    enabled,
    refetchInterval: (query) => listPollInterval(query.state.data, settingsOpen, Date.now()),
  });
  return { activity: investigationActivity(data?.lenses ?? []), list: data };
}

const PANEL =
  "flex min-h-0 flex-1 flex-col overflow-y-auto animate-in fade-in-0 duration-300 motion-reduce:animate-none";

function LensContent({ userRole, readOnly }: Omit<WorkspaceProps, "accessToken">) {
  const host = useLensHost();
  const embedded = host.surface === "embedded";
  const spendLogs = host.traces === "spend-logs";
  const [pageActions, setPageActions] = useState<HTMLDivElement | null>(null);
  const accessToken = useLensAccessToken();
  const { tab, defaultTab: entryTab, lensId, demo, settingUp, setTab, setDemo, setSetup } = useLensRoute();
  const github = useGitHubRoute();
  const { dialog } = useDialogRoute();
  const { issueKey } = useIssueRoute();
  const { trace, openTrace } = useOpenTraceRouting();
  const agents = useLensAgents(accessToken);
  const canViewInvestigations = !spendLogs && isProxyAdminTierRole(userRole);
  const isAdmin = isProxyAdminRole(userRole);
  const canConfigure = canViewInvestigations && !readOnly;
  const connectGitHub =
    canConfigure && !demo
      ? (name: string) => {
          github.open(name);
        }
      : undefined;
  const defaultTab = embedded && entryTab === "home" ? "traces" : entryTab;
  const requestedTab = tab === "settings" && !canConfigure ? defaultTab : tab ?? defaultTab;
  const activeTab =
    spendLogs && requestedTab !== "agents" ? "traces" : requestedTab === "investigations" ? "findings" : requestedTab;
  useEffect(() => {
    if (requestedTab === "investigations") setTab("findings");
  }, [requestedTab, setTab]);
  const setupState = useLensReadiness(canViewInvestigations);
  const setupLocation = {
    tab: activeTab,
    requested: settingUp,
    canViewInvestigations,
    trace,
    lensId,
    dialog,
    issueKey,
  };
  const showSetup = !spendLogs && !demo && (settingUp || (embedded && needsSetup(setupState, setupLocation)));
  const traceWorkspace = activeTab === "traces" && !showSetup;
  const connectProject =
    !spendLogs && !demo
      ? () => {
          setSetup(false);
          setTab("home");
        }
      : undefined;
  const { activity, list } = useLensOverview(
    canViewInvestigations,
    (canConfigure && activeTab === "settings") || settingUp,
  );
  const workers = canConfigure && list ? list.workers : null;
  const leaveSetup = () => {
    setSetup(false);
  };
  const startSetup = () => {
    setSetup(true);
  };
  const exitSetup = (to: LensTab) => {
    leaveSetup();
    setTab(to);
  };
  const showSettings = () => {
    leaveSetup();
    setTab("settings");
  };
  const showFindings = () => {
    leaveSetup();
    setTab("findings");
  };
  const showSentTrace = (trace: TraceSummary) => {
    leaveSetup();
    if (trace.agent_names?.[0]) agents.select(trace.agent_names[0]);
    setTab("traces");
    openTrace(traceRefOf(trace));
  };
  const toggleDemo = (next: boolean) => {
    leaveSetup();
    setDemo(next);
  };
  const onboarding: Onboarding = {
    readOnly,
    canViewInvestigations,
    canInvestigate: !spendLogs && isAdmin,
    canMintTracingKey: !spendLogs && isAdmin,
    connect: showSettings,
    create: showFindings,
    openTrace: showSentTrace,
  };
  const navigate = (tab: LensTab) => {
    leaveSetup();
    setTab(tab);
  };
  return (
    <OnboardingProvider value={onboarding}>
      <main
        className={cn(
          "lens-workspace relative flex h-full min-h-0 w-full min-w-0 flex-1 bg-background",
          embedded && "lens-embedded",
          !embedded && "lens-shell",
        )}
      >
        <LensPageActionsContext.Provider value={{ target: pageActions, tab: activeTab }}>
          <Tabs.Root
            value={activeTab}
            orientation={embedded ? "horizontal" : "vertical"}
            onValueChange={(value) => navigate(value as LensTab)}
            className="@container/lens-frame flex min-h-0 min-w-0 flex-1 gap-0"
          >
            {!embedded && <LensSidebar agents={agents} activity={activity} workers={workers} onNavigate={navigate} />}
            <div className={cn("flex min-h-0 min-w-0 flex-1 flex-col", !embedded && "lens-workspace-paper")}>
              {embedded ? (
                <header aria-label="Lens navigation and actions" className="lens-embedded-toolbar">
                  <h1 className="sr-only">Lens</h1>
                  <div className="min-w-0 max-w-full overflow-x-auto">
                    <LensTabs orientation="horizontal" activity={activity} workers={workers} onNavigate={navigate} />
                  </div>
                  <div className="ml-auto flex max-w-full flex-wrap items-center gap-2">
                    {agents.agent && (
                      <AgentPicker agent={agents.agent} agents={agents.list.agents} onSelect={agents.select} />
                    )}
                    <div ref={setPageActions} role="group" aria-label="Page actions" className="contents" />
                    {connectGitHub && agents.agent && activeTab !== "agents" && activeTab !== "home" && (
                      <Button
                        variant="outline"
                        size="icon-sm"
                        aria-label="Connect GitHub"
                        title="Connect GitHub"
                        onClick={() => connectGitHub(agents.agent!)}
                      >
                        <Github aria-hidden="true" className="size-4" />
                      </Button>
                    )}
                    <DemoToggle demo={demo} onChange={toggleDemo} />
                    <a
                      href="https://docs.litellm.ai/docs/proxy/lens"
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="Documentation"
                      title="Documentation"
                      className="rounded-sm p-1 text-muted-foreground hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <BookOpen aria-hidden="true" className="size-4" />
                    </a>
                  </div>
                </header>
              ) : (
                <header className="lens-workspace-header flex h-14 shrink-0 items-center justify-between gap-3 border-b bg-card pr-4 pl-14 md:px-6">
                  <div className="flex min-w-0 items-center gap-2 text-sm">
                    <span aria-hidden="true" className="lens-breadcrumb-dot mr-1 size-1.5 shrink-0 rounded-full" />
                    {activeTab === "traces" && agents.agent && (
                      <>
                        <Button
                          variant="link"
                          size="sm"
                          className="h-auto p-0 text-muted-foreground"
                          onClick={() => navigate("agents")}
                        >
                          Agents
                        </Button>
                        <ChevronRight aria-hidden="true" className="size-3.5 shrink-0 text-muted-foreground/60" />
                        <span className="hidden max-w-64 truncate text-muted-foreground sm:inline">{agents.agent}</span>
                        <ChevronRight
                          aria-hidden="true"
                          className="hidden size-3.5 shrink-0 text-muted-foreground/60 sm:block"
                        />
                      </>
                    )}
                    <h1 className="truncate font-medium">{LENS_TABS[activeTab]}</h1>
                  </div>
                  <div className="flex shrink-0 items-center gap-3">
                    {connectGitHub && agents.agent && activeTab !== "agents" && activeTab !== "home" && (
                      <Button
                        variant="outline"
                        size="sm"
                        aria-label="Connect GitHub"
                        title="Connect GitHub"
                        onClick={() => connectGitHub(agents.agent!)}
                      >
                        <Github aria-hidden="true" className="size-4" />{" "}
                        <span className="hidden sm:inline">Connect GitHub</span>
                      </Button>
                    )}
                    <DemoToggle demo={demo} onChange={toggleDemo} />
                  </div>
                </header>
              )}
              <div
                className={cn(
                  "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden bg-card",
                  !embedded && !traceWorkspace && "m-2 rounded-xl border md:m-4",
                )}
              >
                {showSetup ? (
                  <TabsContent value={activeTab} keepMounted className={cn(PANEL, "lens-page-body")}>
                    {setupState.loading ? (
                      <p role="status" className="flex items-center gap-2 py-8 text-sm text-muted-foreground">
                        <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                        Checking Lens setup…
                      </p>
                    ) : (
                      <LensGettingStarted state={setupState} onStart={startSetup} onExit={exitSetup} />
                    )}
                  </TabsContent>
                ) : (
                  <>
                    {!spendLogs && (
                      <TabsContent value="home" keepMounted className={PANEL}>
                        <LensHome
                          key={accessToken}
                          agents={agents}
                          enabled={!demo && activeTab === "home"}
                          onOpenAgents={() => navigate("agents")}
                          onSetup={canConfigure ? startSetup : undefined}
                        />
                      </TabsContent>
                    )}
                    <TabsContent value="agents" className={PANEL}>
                      <AgentsView
                        agents={agents}
                        onOpenAgent={agents.select}
                        onConnectProject={connectProject}
                        onConnectGitHub={connectGitHub}
                      />
                    </TabsContent>
                    <TabsContent value="traces" keepMounted className={PANEL}>
                      <AgentTracesPage
                        accessToken={accessToken}
                        isActive={activeTab === "traces"}
                        readOnly={readOnly}
                        canMintTracingKey={!spendLogs && isAdmin}
                        canViewFindings={canViewInvestigations}
                        onSetUpSignals={canConfigure ? showSettings : undefined}
                        onConnectAgent={connectProject}
                      />
                    </TabsContent>
                    <TabsContent value="profiles" className={PANEL}>
                      <ProfilesView agents={agents} canInvestigate={canConfigure && isAdmin} />
                    </TabsContent>
                    <TabsContent value="findings" className={PANEL}>
                      {canViewInvestigations ? (
                        dialog === "new" && canConfigure && isAdmin ? (
                          <InvestigationsView readOnly={false} />
                        ) : (
                          <FindingsView agent={agents.agent ?? undefined} readOnly={readOnly || !isAdmin} />
                        )
                      ) : (
                        <p className="py-6 text-sm text-muted-foreground">
                          Findings require proxy administrator access.
                        </p>
                      )}
                    </TabsContent>
                    <TabsContent value="datasets" className={PANEL}>
                      <DatasetsPanel canView={canViewInvestigations} isAdmin={isAdmin} readOnly={readOnly} />
                    </TabsContent>
                    <TabsContent value="evals" className={PANEL}>
                      {canViewInvestigations ? (
                        <EvalsView />
                      ) : (
                        <p className="py-6 text-sm text-muted-foreground">Evals require proxy administrator access.</p>
                      )}
                    </TabsContent>
                  </>
                )}
                {workers && list && (
                  <TabsContent value="settings" keepMounted className={PANEL}>
                    <LensSettings
                      list={list}
                      workerReadyAction={
                        list.lenses.length === 0 ? (
                          <Button className="w-full" onClick={showFindings}>
                            View automatic analysis
                          </Button>
                        ) : undefined
                      }
                      onConnectProject={connectProject}
                      onSetup={canConfigure ? startSetup : undefined}
                    />
                  </TabsContent>
                )}
              </div>
            </div>
          </Tabs.Root>
        </LensPageActionsContext.Provider>
      </main>
      {github.agent && connectGitHub && (
        <AgentGitHubDialog
          key={github.agent}
          agent={github.agent}
          authorizationId={github.authorizationId}
          onAuthorizationComplete={github.complete}
          onOpenChange={(open) => {
            if (!open) github.close();
          }}
          onOpenDatasets={() => {
            github.close();
            setTab("datasets");
          }}
        />
      )}
    </OnboardingProvider>
  );
}

function DatasetsPanel({ canView, isAdmin, readOnly }: { canView: boolean; isAdmin: boolean; readOnly: boolean }) {
  if (!canView)
    return <p className="py-6 text-sm text-muted-foreground">Datasets require proxy administrator access.</p>;
  return <DatasetsView readOnly={readOnly || !isAdmin} />;
}

function needsSetup(
  state: LensReadiness,
  location: {
    tab: LensTab;
    requested: boolean;
    canViewInvestigations: boolean;
    trace: TraceRef | null;
    lensId: string | null;
    dialog: LensDialog | null;
    issueKey: string | null;
  },
) {
  if (
    location.tab === "settings" ||
    location.tab === "home" ||
    location.tab === "datasets" ||
    location.tab === "evals" ||
    location.tab === "agents"
  )
    return false;
  if (location.requested) return true;
  const selected = location.tab === "traces" ? location.trace : location.lensId || location.dialog || location.issueKey;
  if (!state.missingTraces || selected) return false;
  if (location.tab === "traces") return true;
  return false;
}
