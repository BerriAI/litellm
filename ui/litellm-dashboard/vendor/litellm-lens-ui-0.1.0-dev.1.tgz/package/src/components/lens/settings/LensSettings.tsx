"use client";

import { useState, type ReactNode } from "react";
import { Activity, ArrowUpRight, Cpu } from "lucide-react";
import { Button } from "../../ui/button";
import { StatusDot } from "../../shared/StatusDot";
import { SignalSettings } from "./signals/SignalSettings";
import { SettingsCard, SettingsSection } from "./SettingsSection";
import type { LensList } from "../model/types";
import { STANDALONE_DOCS_URL, useLensHost } from "../../../host/LensHost";
import { DeploymentAnalysis } from "./worker/DeploymentAnalysis";
import { LensPageHeader } from "../ui/LensPageHeader";
import { GatewayConnection } from "./GatewayConnection";
import { TracingKeysDialog } from "../onboarding/tracing/TracingKeysDialog";
import { useTracesLive } from "../traces/api";

const TRACING_DOCS = "https://docs.litellm.ai/docs/proxy/lens";

function TracingSection({
  enabled,
  onConnectProject,
  onSetup,
}: {
  enabled: boolean;
  onConnectProject?: () => void;
  onSetup?: () => void;
}) {
  const standalone = useLensHost().surface === "standalone";
  const [manageKeys, setManageKeys] = useState(false);
  const live = useTracesLive();
  return (
    <SettingsSection
      heading="Tracing"
      icon={<Activity aria-hidden="true" className="size-4" />}
      description="Where your agents send runs so Lens can read them."
    >
      <SettingsCard className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 text-sm">
          <span
            role="status"
            className="inline-flex items-center gap-2 text-sm"
          >
            <StatusDot state={enabled ? "ok" : "off"} />
            {enabled ? "Tracing enabled" : "Tracing is not enabled"}
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {live && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setManageKeys(true)}
            >
              Manage tracing keys
            </Button>
          )}
          {onSetup && (
            <Button variant="outline" size="sm" onClick={onSetup}>
              Deployment setup
            </Button>
          )}
          <a
            href={standalone ? STANDALONE_DOCS_URL : TRACING_DOCS}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
          >
            Docs
            <ArrowUpRight aria-hidden="true" className="size-3" />
          </a>
          <Button
            variant="outline"
            size="sm"
            onClick={onConnectProject}
            disabled={!onConnectProject}
          >
            Connect project
          </Button>
        </div>
      </SettingsCard>
      {live && (
        <TracingKeysDialog open={manageKeys} onOpenChange={setManageKeys} />
      )}
    </SettingsSection>
  );
}

export function LensSettings({
  list,
  workerReadyAction,
  onConnectProject,
  onSetup,
}: {
  list: LensList;
  workerReadyAction?: ReactNode;
  onConnectProject?: () => void;
  onSetup?: () => void;
}) {
  const standalone = useLensHost().surface === "standalone";
  return (
    <div aria-label="Settings" role="region" className="flex w-full flex-col">
      <LensPageHeader
        page="settings"
        title="Settings"
        description="Manage connections, signals, and automatic analysis"
      />
      <div className="lens-page-body w-full max-w-6xl divide-y divide-border">
        <TracingSection
          enabled={list.tracing_enabled}
          onConnectProject={onConnectProject}
          onSetup={onSetup}
        />
        {standalone && <GatewayConnection />}
        <SignalSettings />
        <SettingsSection
          heading="Analysis"
          icon={<Cpu aria-hidden="true" className="size-4" />}
          description="Lens analyzes traces and surfaces issues in Findings."
        >
          <DeploymentAnalysis
            workers={list.workers}
            readyAction={workerReadyAction}
          />
        </SettingsSection>
      </div>
    </div>
  );
}
