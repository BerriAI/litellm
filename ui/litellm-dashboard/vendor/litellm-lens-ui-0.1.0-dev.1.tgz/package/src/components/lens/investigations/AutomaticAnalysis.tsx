"use client";

import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Activity, LoaderCircle, Settings2 } from "lucide-react";
import { useNow } from "../../../hooks/useNow";
import { SearchSelect } from "../../shared/SearchSelect";
import { Button } from "../../ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "../../ui/dialog";
import { Input } from "../../ui/input";
import { Switch } from "../../ui/switch";
import { Textarea } from "../../ui/textarea";
import { useLensApi } from "../data/LensServices";
import { useSaveLens } from "../data/mutations";
import { useAnalysisModels } from "../setup/fields/useAnalysisModels";
import { analysisModelOptions, modelGate } from "../setup/fields/analysisModels";
import { useLensRoute } from "../route";
import type { InvestigatorStatus, Lens, Settings } from "../model/types";

import { InvestigatorAnalysis } from "./InvestigatorAnalysis";

function AnalysisSettings({ lens, onClose }: { lens: Lens; onClose: () => void }) {
  const models = useAnalysisModels();
  const save = useSaveLens();
  const [settings, setSettings] = useState<Settings>(lens.settings);
  const gate = modelGate(models, settings.model, settings.model === lens.settings.model);
  const pausingSavedModel = !settings.enabled && settings.model === lens.settings.model;
  const valid =
    (gate.modelValid || pausingSavedModel) &&
    Number.isSafeInteger(settings.interval_minutes) &&
    settings.interval_minutes > 0 &&
    (settings.context.trim() || settings.checks?.some((check) => check.enabled));
  return (
    <Dialog open onOpenChange={(open) => !open && !save.isPending && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Findings settings</DialogTitle>
          <DialogDescription>
            Choose how Lens reviews traces for {lens.settings.agent_name}. Changes apply to the next run.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-5">
          <div className="space-y-2">
            <label className="text-sm font-medium" htmlFor="analysis-model">
              Model
            </label>
            <SearchSelect
              inputId="analysis-model"
              aria-label="Analysis model"
              options={analysisModelOptions(models.models, models.modelDetails)}
              value={settings.model}
              onValueChange={(model) => model && setSettings({ ...settings, model })}
              allowClear={false}
            />
            {(gate.unavailable || gate.unsupported) && (
              <p role="status" className="text-xs text-muted-foreground">
                This model is unavailable for analysis. Choose another model or pause automatic analysis.
              </p>
            )}
            {models.modelsError && (
              <p role="alert" className="text-xs text-destructive">
                Could not load models: {models.modelsError}
              </p>
            )}
          </div>
          <div className="space-y-2">
            <label htmlFor="analysis-context" className="text-sm font-medium">
              Prompt
            </label>
            <Textarea
              id="analysis-context"
              rows={5}
              value={settings.context}
              onChange={(event) => setSettings({ ...settings, context: event.target.value })}
            />
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <label htmlFor="analysis-frequency" className="text-sm font-medium">
                Frequency (minutes)
              </label>
              <Input
                id="analysis-frequency"
                type="number"
                min={1}
                value={settings.interval_minutes}
                onChange={(event) =>
                  setSettings({
                    ...settings,
                    interval_minutes: Number(event.target.value),
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="analysis-budget" className="text-sm font-medium">
                Monthly findings budget (USD)
              </label>
              <Input
                id="analysis-budget"
                type="number"
                min={0.01}
                step={0.01}
                value={settings.monthly_budget}
                onChange={(event) =>
                  setSettings({
                    ...settings,
                    monthly_budget: Number(event.target.value),
                  })
                }
              />
            </div>
          </div>
          <details className="border-t pt-4">
            <summary className="cursor-pointer text-xs text-muted-foreground">Advanced</summary>
            <div className="space-y-4 pt-4">
              <div className="flex items-center justify-between text-sm font-medium">
                <label htmlFor="analysis-enabled">Automatic analysis</label>
                <Switch
                  id="analysis-enabled"
                  checked={settings.enabled}
                  onCheckedChange={(enabled) => setSettings({ ...settings, enabled })}
                />
              </div>
              {settings.checks?.map((check, index) => (
                <div key={check.id} className="space-y-2">
                  <label htmlFor={`analysis-check-${index}`} className="text-sm font-medium">
                    Additional instruction {index + 1}
                    {!check.enabled && " (paused)"}
                  </label>
                  <Textarea
                    id={`analysis-check-${index}`}
                    value={check.instruction}
                    onChange={(event) =>
                      setSettings({
                        ...settings,
                        checks: settings.checks?.map((item, at) =>
                          at === index ? { ...item, instruction: event.target.value } : item,
                        ),
                      })
                    }
                  />
                </div>
              ))}
            </div>
          </details>
          <p className="text-xs leading-5 text-muted-foreground">
            The first automatic run waits for 10 traces. Later runs review new traces from the last{" "}
            {settings.lookback_hours} hours, up to {settings.sample_size ?? "all"} per run. Recent traces settle for 2
            minutes before analysis.
          </p>
        </div>
        {save.error && (
          <p role="alert" className="text-sm text-destructive">
            {save.error.message}
          </p>
        )}
        <DialogFooter>
          <Button variant="outline" disabled={save.isPending} onClick={onClose}>
            Cancel
          </Button>
          <Button
            disabled={
              !valid || !Number.isFinite(settings.monthly_budget) || settings.monthly_budget <= 0 || save.isPending
            }
            onClick={() => save.mutate({ id: lens.id, settings }, { onSuccess: onClose })}
          >
            {save.isPending ? "Saving…" : "Save changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AgentAnalysis({
  lens,
  readOnly,
  ready,
  availableModels,
}: {
  lens: Lens;
  readOnly: boolean;
  ready: boolean;
  availableModels: readonly string[] | null;
}) {
  const api = useLensApi();
  const now = useNow(30_000);
  const [editing, setEditing] = useState(false);
  const job = lens.jobs?.[0];
  const active = lens.jobs?.find((item) => item.status === "running" || item.status === "queued");
  const modelUnavailable =
    availableModels !== null && !availableModels.includes(active?.settings.model ?? lens.settings.model);
  const running = active?.status === "running";
  const first = !job && !lens.last_scan_at && lens.id.startsWith("auto-agent-");
  const sample = useQuery({
    queryKey: ["lens", "automatic-sample", api.scope, lens.id, lens.revision],
    queryFn: () => api.sample(lens.settings, 0, new Date().toISOString()),
    enabled: first && lens.settings.enabled && ready && !modelUnavailable,
    refetchInterval: 30_000,
  });
  const waiting = Math.max(0, 10 - (sample.data?.eligible ?? 0));
  const status =
    active && (running || !modelUnavailable)
      ? active.status === "running"
        ? "Running"
        : "Queued"
      : !lens.settings.enabled
        ? "Paused"
        : modelUnavailable
          ? "Selected model unavailable"
          : !ready
            ? "Waiting for connection"
            : first
              ? sample.error
                ? "Trace count unavailable"
                : sample.isPending
                  ? "Checking traces"
                  : waiting
                    ? `Waiting for traces · ${sample.data?.eligible ?? 0}/10`
                    : "Ready for first analysis"
              : job?.status === "failed" || job?.error
                ? "Last analysis failed"
                : job?.status === "cancelled"
                  ? "Last analysis cancelled"
                  : "Scheduled";
  const next = !lens.settings.enabled
    ? "Enable analysis to resume"
    : modelUnavailable
      ? "Configure another model or pause analysis. Your saved model has not been changed."
      : !ready
        ? "Connect an analysis model in Settings"
        : first
          ? sample.error
            ? "Retrying the trace count automatically"
            : sample.isPending
              ? "Checking received traces"
              : `${waiting} more ${waiting === 1 ? "trace" : "traces"} before the first run`
          : Date.parse(lens.next_run_at) <= now
            ? "Next run: waiting for worker"
            : `Next run: ${new Date(lens.next_run_at).toLocaleString()}`;
  return (
    <section
      aria-label="Findings settings"
      className="flex shrink-0 flex-wrap items-center justify-between gap-x-4 gap-y-2 border-b bg-background px-4 py-3"
    >
      <div className="min-w-0 flex-1 space-y-1 text-xs">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <p role="status" className="flex items-center gap-2 text-foreground">
            {active && (running || !modelUnavailable) ? (
              <LoaderCircle aria-hidden className="size-3.5 text-muted-foreground motion-safe:animate-spin" />
            ) : (
              <Activity aria-hidden className="size-3.5 text-muted-foreground" />
            )}
            {status}
          </p>
          <p className="text-muted-foreground">{active && (running || !modelUnavailable) ? active.stage : next}</p>
        </div>
        {job?.error && (
          <p role="alert" className="max-w-2xl break-words text-destructive">
            {job.error}
          </p>
        )}
        {sample.error && (
          <p role="alert" className="text-destructive">
            {sample.error.message}
          </p>
        )}
      </div>
      {!readOnly && (
        <Button variant="outline" size="sm" aria-label="Findings settings" onClick={() => setEditing(true)}>
          <Settings2 aria-hidden className="size-3.5" />
          Settings
        </Button>
      )}
      {editing && <AnalysisSettings lens={lens} onClose={() => setEditing(false)} />}
    </section>
  );
}

export function AutomaticAnalysis({
  investigator,
  lenses,
  agent = "",
  readOnly,
  ready,
}: {
  investigator?: InvestigatorStatus | null;
  lenses: Lens[];
  agent?: string;
  readOnly: boolean;
  ready: boolean;
}) {
  const { setTab, demo } = useLensRoute();
  const models = useAnalysisModels();
  const availableModels = !demo && !models.modelsLoading && !models.modelsError ? models.models : null;
  const matching = agent ? lenses.filter((lens) => lens.settings.agent_name === agent) : [];
  const lens = matching.find((item) => item.id.startsWith("auto-agent-")) ?? matching[0];
  if (investigator && investigator.agent_name === agent && matching.some((item) => item.id === investigator.lens_id))
    return <InvestigatorAnalysis investigator={investigator} />;
  if (lens)
    return (
      <AgentAnalysis key={lens.id} lens={lens} readOnly={readOnly} ready={ready} availableModels={availableModels} />
    );
  return (
    <section
      aria-label="Findings settings"
      className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-b px-4 py-3 text-xs text-muted-foreground"
    >
      <p role="status">
        {!ready
          ? "Connect an analysis model to start receiving findings."
          : agent
            ? "Waiting for traces. Findings start automatically after 10 traces from this agent."
            : "Select an agent to tune its findings."}
      </p>
      {!ready && !readOnly && (
        <Button variant="outline" size="sm" onClick={() => setTab("settings")}>
          Connect model
        </Button>
      )}
    </section>
  );
}
