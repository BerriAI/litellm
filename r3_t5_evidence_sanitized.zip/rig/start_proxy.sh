#!/usr/bin/env bash
# usage: start_proxy.sh <worktree> <config> <port> <dbname> <logfile>  (PY overrides interpreter, EXTRA_ENV="K=V K=V")
set -u
WT=$1; CFG=$2; PORT=$3; DB=$4; LOG=$5
URL=$(python3 /home/ubuntu/t5_verify/rig/pgurl.py "$DB")
PGURL_ADMIN=$(python3 /home/ubuntu/t5_verify/rig/pgurl.py postgres)
psql "$PGURL_ADMIN" -tAc "select 1 from pg_database where datname='$DB'" | grep -q 1 || psql "$PGURL_ADMIN" -qc "create database \"$DB\""
cd "$WT"
env ${EXTRA_ENV:-} DATABASE_URL="$URL" LITELLM_MASTER_KEY=REDACTED_TEST_MASTER_KEY LITELLM_LOG=INFO \
  nohup "${PY:-.venv/bin/python}" -m litellm.proxy.proxy_cli --config "$CFG" --port "$PORT" --host 127.0.0.1 > "$LOG" 2>&1 &
echo $! > "$LOG.pid"
for i in $(seq 1 180); do curl -sf "http://127.0.0.1:$PORT/health/liveliness" >/dev/null 2>&1 && { echo "up pid $(cat $LOG.pid) after ${i}s"; exit 0; }; sleep 1; done
echo "proxy failed to start"; tail -20 "$LOG"; exit 1
