#!/bin/bash
# container lifecycle on the source-built image: opt-in capture startup, request success, SIGTERM drain
A=/home/ubuntu/t5_verify/artifacts; IMG=litellm-t5:a2fbb6d; NAME=t5c
docker rm -f $NAME >/dev/null 2>&1
docker run -d --name $NAME --network host -v /home/ubuntu/t5_verify/rig/config_capture.yaml:/app/t5config.yaml:ro -e DATABASE_URL='postgresql://REDACTED_USER:REDACTED_PASSWORD@127.0.0.1:5432/t5_docker' -e OPENAI_API_KEY -e ANTHROPIC_API_KEY -e GEMINI_API_KEY -e LITELLM_MASTER_KEY=REDACTED_TEST_MASTER_KEY -e PORT=4330 $IMG --config /app/t5config.yaml --port 4330 > /dev/null
echo "image: $(docker image inspect $IMG --format '{{.Id}} created={{.Created}}')"; echo "container python: $(docker exec $NAME python --version 2>&1)"
for i in $(seq 1 120); do curl -sf http://127.0.0.1:4330/health/liveliness >/dev/null && break; sleep 2; done; echo "up after $((i*2))s"
M=t5dock-$RANDOM; for i in 1 2 3; do curl -s -o /dev/null -w "%{http_code} " -X POST http://127.0.0.1:4330/v1/chat/completions -H 'Authorization: Bearer REDACTED_TEST_MASTER_KEY' -H 'Content-Type: application/json' -d "{\"model\":\"chat-openai\",\"messages\":[{\"role\":\"user\",\"content\":\"say ok\"}],\"max_tokens\":5,\"user\":\"$M\"}"; done; echo
sleep 1; T0=$(date +%s.%N); docker stop -t 30 $NAME >/dev/null; T1=$(date +%s.%N); echo "SIGTERM (docker stop) -> exit in $(echo "$T1-$T0" | bc)s, exit code $(docker inspect $NAME --format '{{.State.ExitCode}}')"
echo "events for marker after exit: $(psql 'postgresql://REDACTED_USER:REDACTED_PASSWORD@127.0.0.1:5432/t5_docker' -tAc "select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like '%$M%'")"
docker logs $NAME 2>&1 | grep -iE "accounting|usage capture|graceful|drain|shutdown complete|Draining" | head -8 | cut -c1-160
docker logs $NAME > $A/r3_docker_container.log 2>&1; docker rm $NAME >/dev/null
