#!/bin/bash
# Crash boundaries: async pre-commit loss window (kill -9 before flush) vs sync-ack committed-before-200; restart -> no double apply.
set -u; cd /home/ubuntu/t5_verify; M=t5crash3-$(head -c3 /dev/urandom | xxd -p)
q() { psql "$(python3 rig/pgurl.py $1)" -tAc "$2"; }
req() { curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer REDACTED_TEST_MASTER_KEY" -H "Content-Type: application/json" http://127.0.0.1:$1/v1/chat/completions -d "{\"model\":\"chat-openai\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_completion_tokens\":5,\"user\":\"$M-$2\"}"; }
echo "--- async (flush 5s) on 4326/t5_crash_async3"
./rig/start_proxy.sh /home/ubuntu/repos/wt-head /home/ubuntu/t5_verify/rig/config_capture_slow.yaml 4326 t5_crash_async3 /home/ubuntu/t5_verify/artifacts/r3_proxy_crash_async.log | tail -1
echo "async http=$(req 4326 async)"; kill -9 $(cat artifacts/r3_proxy_crash_async.log.pid); echo "killed -9 immediately"; sleep 2
echo "events for async request after kill: $(q t5_crash_async3 "select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like '%$M-async%'") (expected 0 = documented pre-commit loss window)"
./rig/start_proxy.sh /home/ubuntu/repos/wt-head /home/ubuntu/t5_verify/rig/config_capture_slow.yaml 4326 t5_crash_async3 /home/ubuntu/t5_verify/artifacts/r3_proxy_crash_async2.log | tail -1
sleep 6; echo "events after restart (no replay source): $(q t5_crash_async3 "select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like '%$M-async%'")"
echo "control: async http=$(req 4326 ctl)"; sleep 7; echo "control events after flush: $(q t5_crash_async3 "select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like '%$M-ctl%'")"
kill $(cat artifacts/r3_proxy_crash_async2.log.pid)
echo "--- sync-ack fail_closed on 4304/t5_head_sync"
echo "sync http=$(req 4304 sync)"; kill -9 $(cat artifacts/r3_proxy_head_sync.log.pid); echo "killed -9 immediately"; sleep 1
echo "events for acked sync request: $(q t5_head_sync "select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like '%$M-sync%'") (expected 2)"
./rig/start_proxy.sh /home/ubuntu/repos/wt-head /home/ubuntu/t5_verify/rig/config_syncack_failclosed.yaml 4304 t5_head_sync /home/ubuntu/t5_verify/artifacts/r3_proxy_head_sync2.log | tail -1
echo "post-restart sync http=$(req 4304 sync2)"; sleep 2
echo "events sync/sync2: $(q t5_head_sync "select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like '%$M-sync%'") ; distinct event_ids = rows: $(q t5_head_sync "select count(*)=count(distinct event_id) from \"LiteLLM_AccountingEvent\"")"
echo "deliveries per event (min/max) : $(q t5_head_sync "select min(c), max(c) from (select count(*) c from \"LiteLLM_AccountingDelivery\" group by event_id) s")"
