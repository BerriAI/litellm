"""D1/D2 outage: warm pool, drop DB connections via relay, submit sync-ack request, restore, prove admitted writes commit."""
import json, os, sys, time, uuid, subprocess, httpx, psycopg2
url, db, out, label = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
CTL = "/tmp/t5_relay_down"; m = f"t5out-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
c = httpx.Client(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=60)
def events(scope):
    cur.execute("select event_id, kind::text, payload->'event'->>'outcome', payload->>'usage_source' from \"LiteLLM_AccountingEvent\" where payload::text like %s order by event_id", (f"%{scope}%",)); return cur.fetchall()
def chat(tag):
    t0 = time.time(); r = c.post("/v1/chat/completions", json={"model": "chat-openai", "messages": [{"role": "user", "content": "hi"}], "user": f"{m}-{tag}"}); return r, round((time.time() - t0) * 1000)
res = {"marker": m, "label": label, "steps": []}
for i in range(2):
    r, ms = chat(f"warm{i}"); res["steps"].append({"step": f"warm{i}", "status": r.status_code, "ms": ms, "events": len(events(f"{m}-warm{i}"))}); print("warm", r.status_code, ms, "ms events", len(events(f"{m}-warm{i}")))
open(CTL, "w").close(); print("relay DOWN"); t_down = time.time()
r, ms = chat("down"); body = r.text[:200]
print("during outage:", r.status_code, ms, "ms", body)
res["steps"].append({"step": "during_outage", "status": r.status_code, "ms": ms, "body": body, "call_id": r.headers.get("x-litellm-call-id")})
time.sleep(max(0, 8 - (time.time() - t_down))); os.remove(CTL); print("relay UP after", round(time.time() - t_down, 1), "s"); t_up = time.time()
ev = []
for _ in range(90):
    ev = events(f"{m}-down")
    if len(ev) >= 2: break
    time.sleep(1)
print("events for outage request after restore:", ev, "recovered in", round(time.time() - t_up, 1), "s")
res["steps"].append({"step": "after_restore", "events": [list(e) for e in ev], "recover_s": round(time.time() - t_up, 1)})
r, ms = chat("post"); time.sleep(1); print("post-restore:", r.status_code, ms, "ms events", len(events(f"{m}-post")))
res["steps"].append({"step": "post_restore", "status": r.status_code, "ms": ms, "events": len(events(f"{m}-post"))})
json.dump(res, open(out, "w"), indent=1)
