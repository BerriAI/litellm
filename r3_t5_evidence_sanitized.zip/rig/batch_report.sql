select count(*) accounting_txns, sum(c) events, min(c) min_batch, max(c) max_batch, round(avg(c),1) avg_batch from (select txid, count(*) c from t5_txn_probe group by txid) s;
