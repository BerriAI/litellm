"""Gate 2 latency breakdown for sync-ack during a DB outage: client total vs provider window (SpendLogs start/end) vs receipt wait (log timestamps)."""
import json, os, re, sys, time, uuid, subprocess, httpx, psycopg2
from datetime import datetime, timezone
url, db, log, out, policy = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
CTL = "/tmp/t5_relay_down"; m = f"t5lat-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
c = httpx.Client(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=90)
def chat(tag):
    t0 = time.time(); r = c.post("/v1/chat/completions", json={"model": "chat-openai", "messages": [{"role": "user", "content": "hi"}], "max_completion_tokens": 5, "user": f"{m}-{tag}"}); return r, t0, time.time()
for i in range(2): chat(f"warm{i}")
lines0 = sum(1 for _ in open(log, errors="ignore"))
open(CTL, "w").close(); t_down = time.time(); time.sleep(0.5)
r, t0, t1 = chat("down"); call_id = r.headers.get("x-litellm-call-id")
time.sleep(max(0, 8 - (time.time() - t_down))); os.remove(CTL); t_up = time.time()
time.sleep(25)
new = open(log, errors="ignore").read().splitlines()[lines0:]
def ts(line):
    mm = re.match(r"(\d\d:\d\d:\d\d)", line); return mm.group(1) if mm else None
marks = {}
for l in new:
    if call_id and call_id in l and "start" not in marks: marks["first_log_with_call_id"] = ts(l)
    if "Usage capture failed before the response boundary" in l: marks["receipt_wait_end"] = ts(l)
    if "retaining admitted batch" in l and "first_retry_warning" not in marks: marks["first_retry_warning"] = ts(l)
    if "HTTP/1.1\" 503" in l or "HTTP/1.1\" 200" in l:
        if call_id is None or True: marks["last_access_log"] = ts(l)
    if "Logging Details LiteLLM-Success Call" in l and "success_callback_start" not in marks: marks["success_callback_start"] = ts(l)
    if "accounting_sync_ack" in l and "wait" in l.lower(): marks.setdefault("ack_wait_lines", []).append(l[:140])
cur.execute("select \"startTime\", \"endTime\", status, spend, total_tokens from \"LiteLLM_SpendLogs\" where end_user=%s", (f"{m}-down",)); sl = cur.fetchall()
cur.execute("select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like %s", (f"%{m}-down%",)); ev = cur.fetchone()[0]
res = {"policy": policy, "marker": m, "call_id": call_id, "http": r.status_code, "client_total_s": round(t1 - t0, 2), "client_send_utc": datetime.fromtimestamp(t0, timezone.utc).strftime("%H:%M:%S"), "client_recv_utc": datetime.fromtimestamp(t1, timezone.utc).strftime("%H:%M:%S"), "outage_s": round(t_up - t_down, 1), "spendlogs_start_end": [[str(x) for x in row] for row in sl], "log_marks": marks, "events_after_restore": ev}
print(json.dumps(res, indent=1)); json.dump(res, open(out, "w"), indent=1)
