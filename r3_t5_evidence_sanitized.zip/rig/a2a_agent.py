"""Scripted local A2A agent: agent card + JSON-RPC message/send (two internal rounds reported via usage metadata-free reply)."""
import json, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
PORT = int(sys.argv[1])
CARD = {"protocolVersion": "0.3", "name": "t5-scripted-agent", "description": "scripted", "version": "1.0.0", "url": f"http://127.0.0.1:{PORT}/", "capabilities": {"streaming": False}, "defaultInputModes": ["text"], "defaultOutputModes": ["text"], "skills": []}
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, obj, code=200):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self): self._send(CARD)
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0)) or 0) or b"{}")
        text = body.get("params", {}).get("message", {}).get("parts", [{}])[0].get("text", "")
        self._send({"jsonrpc": "2.0", "id": body.get("id"), "result": {"kind": "message", "role": "agent", "messageId": "m-" + str(body.get("id")), "parts": [{"kind": "text", "text": f"scripted reply to: {text}"}]}})
HTTPServer(("127.0.0.1", PORT), H).serve_forever()
