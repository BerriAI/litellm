"""Overload: capture-on proxy (max_pending_records 20) behind relay; DB held down; 40 concurrent cheap requests; observe HTTP codes, capture rejections in log, queue bound, recovery."""
import asyncio, json, os, sys, time, uuid, subprocess, httpx, psycopg2
url, db, log, out = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]; CTL = "/tmp/t5_relay_down"; m = f"t5ovl-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
def nev(): cur.execute("select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like %s", (f"%{m}%",)); return cur.fetchone()[0]
async def main():
    lines0 = sum(1 for _ in open(log, errors="ignore")); codes = {}
    async with httpx.AsyncClient(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=120) as c:
        r = await c.post("/v1/chat/completions", json={"model": "chat-openai", "messages": [{"role": "user", "content": "ok"}], "max_completion_tokens": 5, "user": f"{m}-warm"}); print("warm", r.status_code)
        open(CTL, "w").close(); t_down = time.time(); await asyncio.sleep(0.5)
        async def one(i):
            r = await c.post("/v1/chat/completions", json={"model": "chat-openai", "messages": [{"role": "user", "content": "ok"}], "max_completion_tokens": 5, "user": f"{m}-{i}"}); codes[r.status_code] = codes.get(r.status_code, 0) + 1
        await asyncio.gather(*(one(i) for i in range(40)))
        print("during outage codes:", codes, "elapsed", round(time.time() - t_down, 1))
        await asyncio.sleep(max(0, 20 - (time.time() - t_down))); os.remove(CTL); t_up = time.time()
    hist = []
    for _ in range(60):
        hist.append(nev()); 
        if hist[-1] >= 80: break
        await asyncio.sleep(1)
    new = open(log, errors="ignore").read().splitlines()[lines0:]
    rej = [l[-160:] for l in new if "UsageCaptureError" in l or "pending" in l.lower() and "usage" in l.lower() or "backpressure" in l.lower() or "capacity" in l.lower()]
    retry = sum(1 for l in new if "retaining admitted batch" in l)
    res = {"marker": m, "codes": codes, "events_after_restore": hist[-1], "recover_s": len(hist), "retry_warnings": retry, "rejection_lines": rej[:12], "n_rejection_lines": len(rej), "capture_failed": sum(1 for l in new if "Usage capture failed" in l)}
    print(json.dumps(res, indent=1)); json.dump(res, open(out, "w"), indent=1)
asyncio.run(main())
