#!/bin/bash
# Startup rejections: expect proxy to fail fast with the documented ValueError; 90s cap each.
cd /home/ubuntu/t5_verify; A=/home/ubuntu/t5_verify
try() { name=$1; cfg=$2; shift 2; LOG=$A/artifacts/r2_reject_$name.log; URL=$(python3 rig/pgurl.py t5_reject)
  psql "$(python3 rig/pgurl.py postgres)" -tAc "select 1 from pg_database where datname='t5_reject'" | grep -q 1 || psql "$(python3 rig/pgurl.py postgres)" -qc 'create database "t5_reject"'
  (cd /home/ubuntu/repos/wt-head && env "$@" DATABASE_URL="$URL" LITELLM_MASTER_KEY=REDACTED_TEST_MASTER_KEY LITELLM_LOG=INFO timeout 90 .venv/bin/python -m litellm.proxy.proxy_cli --config $cfg --port 4209 --host 127.0.0.1 > $LOG 2>&1; echo "exit=$?" >> $LOG)
  echo "$name: $(tail -1 $LOG) | $(grep -oE 'accounting_sync_ack requires accounting_capture|Usage capture requires local Prisma writes[^\"]*' $LOG | head -1) | liveliness=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:4209/health/liveliness)"; pkill -f "port 4209" 2>/dev/null; sleep 1; }
try syncack_nocapture $A/rig/config_reject_syncack_nocapture.yaml X=1
try remote_writer $A/rig/config_capture.yaml SPEND_LOGS_URL=http://127.0.0.1:9/spend
try collector $A/rig/config_capture.yaml LITELLM_COLLECTOR_ENABLED=true
try search_free_tier $A/rig/config_reject_searchfree.yaml X=1
