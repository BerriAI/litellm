from typing import Optional

import litellm
from litellm.integrations.custom_guardrail import CustomGuardrail
from litellm.proxy._types import UserAPIKeyAuth


class T5PostGuardrail(CustomGuardrail):
    async def async_post_call_success_hook(self, data: dict, user_api_key_dict: UserAPIKeyAuth, response):
        if "-gfail" in str(data.get("user") or data.get("metadata", {}).get("user") or ""):
            raise ValueError("T5 post-call guardrail rejected response")
        return response

    async def async_post_call_streaming_iterator_hook(self, user_api_key_dict: UserAPIKeyAuth, response, request_data: dict):
        async for chunk in response:
            yield chunk
        if "-gfail" in str(request_data.get("user") or ""):
            raise ValueError("T5 post-call streaming guardrail rejected response")
