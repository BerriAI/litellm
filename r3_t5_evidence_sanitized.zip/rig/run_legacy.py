"""Drive the ten legacy scenarios against a proxy and dump HTTP + SpendLogs + accounting rows per scenario."""
import argparse, json, time, uuid, sys
import httpx, psycopg2

HDRS = ("x-litellm-response-cost", "x-litellm-model-id", "x-litellm-key-spend", "x-litellm-call-id", "x-litellm-model-group", "content-type")
PDF = "https://arxiv.org/pdf/1706.03762v7"

def scenarios(marker):
    m = lambda s: f"{marker}-{s}"
    return {
      "chat": ("POST", "/v1/chat/completions", {"model": "chat-openai", "messages": [{"role": "user", "content": f"Say hi {m('chat')}"}], "user": m("chat")}),
      "stream": ("POST", "/v1/chat/completions", {"model": "chat-openai", "stream": True, "stream_options": {"include_usage": True}, "messages": [{"role": "user", "content": f"Count to 3 {m('stream')}"}], "user": m("stream")}),
      "embeddings": ("POST", "/v1/embeddings", {"model": "embed", "input": f"hello {m('emb')}", "user": m("emb")}),
      "responses": ("POST", "/v1/responses", {"model": "chat-openai", "input": f"Say hi {m('resp')}", "user": m("resp")}),
      "text_completion": ("POST", "/v1/completions", {"model": "chat-openai", "prompt": f"Say hi {m('tc')}", "max_tokens": 5, "user": m("tc")}),
      "zero_cost": ("POST", "/v1/chat/completions", {"model": "zero-cost", "messages": [{"role": "user", "content": f"Say hi {m('zc')}"}], "user": m("zc")}),
      "anthropic_messages": ("POST", "/v1/messages", {"model": "chat-anthropic", "max_tokens": 20, "messages": [{"role": "user", "content": f"Say hi {m('am')}"}], "metadata": {"user_id": m("am")}}),
      "ocr": ("POST", "/v1/ocr", {"model": "ocr", "document": {"type": "document_url", "document_url": PDF}, "pages": [0]}),
      "invalid_model": ("POST", "/v1/chat/completions", {"model": "no-such-model", "messages": [{"role": "user", "content": "hi"}], "user": m("im")}),
      "invalid_params": ("POST", "/v1/chat/completions", {"model": "chat-openai", "max_completion_tokens": -5, "messages": [{"role": "user", "content": "hi"}], "user": m("ip")}),
    }

SUFFIX = {"chat":"chat","stream":"stream","embeddings":"emb","responses":"resp","text_completion":"tc","zero_cost":"zc","anthropic_messages":"am","ocr":None,"invalid_model":"im","invalid_params":"ip"}

def db_rows(cur, call_id, scope):
    out = {}
    cur.execute("select request_id, call_type, model, spend, total_tokens, prompt_tokens, completion_tokens, status, end_user, request_tags from \"LiteLLM_SpendLogs\" where request_id=%s or end_user=%s or metadata::text like %s", (call_id or "-", scope, f"%{call_id or scope}%"))
    out["spendlogs"] = [dict(zip(("request_id","call_type","model","spend","total_tokens","prompt_tokens","completion_tokens","status","end_user","tags"), r)) for r in cur.fetchall()]
    cur.execute("select to_regclass('\"LiteLLM_AccountingEvent\"')")
    if cur.fetchone()[0] is None:
        out["accounting_events"] = "table-absent"; return out
    cur.execute("select e.event_id, e.kind::text, e.schema_version, e.occurred_at::text, e.payload, (select json_agg(json_build_object('target',d.target::text,'state',d.state::text,'version',d.version)) from \"LiteLLM_AccountingDelivery\" d where d.event_id=e.event_id) from \"LiteLLM_AccountingEvent\" e where e.payload::text like %s or e.payload::text like %s", (f"%{call_id or '-'}%", f"%{scope}%"))
    out["accounting_events"] = [dict(zip(("event_id","kind","schema_version","occurred_at","payload","deliveries"), r)) for r in cur.fetchall()]
    return out

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--url", required=True); ap.add_argument("--db", required=True); ap.add_argument("--out", required=True); ap.add_argument("--only", default="")
    a = ap.parse_args()
    marker = f"t5-{uuid.uuid4().hex[:8]}"
    conn = psycopg2.connect(__import__("subprocess").check_output(["python3","/home/ubuntu/t5_verify/rig/pgurl.py",a.db],text=True).strip()); conn.autocommit = True; cur = conn.cursor()
    client = httpx.Client(base_url=a.url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=120)
    results = {"marker": marker, "url": a.url, "cases": {}}
    for name, (method, path, body) in scenarios(marker).items():
        if a.only and name not in a.only.split(","): continue
        t0 = time.time(); rec = {"path": path}
        try:
            if body.get("stream"):
                chunks = []; usage = None
                with client.stream(method, path, json=body) as r:
                    rec["status"] = r.status_code; rec["headers"] = {h: r.headers.get(h) for h in HDRS}
                    for line in r.iter_lines():
                        if line.startswith("data: ") and line != "data: [DONE]":
                            c = json.loads(line[6:]); chunks.append(c)
                            if c.get("usage"): usage = c["usage"]
                rec["chunks"] = len(chunks); rec["usage"] = usage
            else:
                r = client.request(method, path, json=body)
                rec["status"] = r.status_code; rec["headers"] = {h: r.headers.get(h) for h in HDRS}
                try:
                    j = r.json(); rec["usage"] = j.get("usage") or j.get("usage_info"); rec["body_keys"] = sorted(j.keys())[:12]
                    if r.status_code >= 400: rec["error"] = json.dumps(j)[:300]
                except Exception: rec["body"] = r.text[:200]
        except Exception as e:
            rec["exception"] = repr(e)[:300]
        rec["latency_ms"] = round((time.time() - t0) * 1000)
        call_id = (rec.get("headers") or {}).get("x-litellm-call-id")
        for _ in range(30):
            rows = db_rows(cur, call_id, f"{marker}-{SUFFIX[name]}" if SUFFIX[name] else call_id or "-")
            if rows["spendlogs"]: break
            time.sleep(0.5)
        rec.update(rows); results["cases"][name] = rec
        print(f"{name:20s} status={rec.get('status')} cost_hdr={ (rec.get('headers') or {}).get('x-litellm-response-cost')} spendlogs={len(rows['spendlogs'])} events={rows['accounting_events'] if isinstance(rows['accounting_events'], str) else len(rows['accounting_events'])} {rec['latency_ms']}ms", flush=True)
    json.dump(results, open(a.out, "w"), indent=1, default=str)

if __name__ == "__main__": main()
