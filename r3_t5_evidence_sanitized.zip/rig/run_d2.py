"""Gate 1 D2: unsupported sync-ack routes over real HTTP. Unique identities, 5s drain, SQL counts (events+deliveries), traceback window, provider dispatch check."""
import json, sys, time, uuid, subprocess, httpx, psycopg2
url, db, log, out = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
c = httpx.Client(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=60)
def cases(m):
    return {
     "stream_chat": ("/v1/chat/completions", {"model": "chat-openai", "stream": True, "messages": [{"role": "user", "content": "hi"}], "user": m}),
     "background_responses": ("/v1/responses", {"model": "chat-openai", "input": "hi", "background": True, "user": m}),
     "ocr": ("/v1/ocr", {"model": "ocr", "document": {"type": "document_url", "document_url": "https://arxiv.org/pdf/1706.03762v7"}, "pages": [0]}),
     "messages": ("/v1/messages", {"model": "chat-anthropic", "max_tokens": 5, "messages": [{"role": "user", "content": "hi"}], "metadata": {"user_id": m}}),
     "ctl_chat": ("/v1/chat/completions", {"model": "chat-openai", "messages": [{"role": "user", "content": "hi"}], "user": m}),
     "ctl_text": ("/v1/completions", {"model": "chat-openai", "prompt": "hi", "max_tokens": 5, "user": m}),
     "ctl_embed": ("/v1/embeddings", {"model": "embed", "input": "hi", "user": m}),
     "ctl_responses": ("/v1/responses", {"model": "chat-openai", "input": "hi", "user": m}),
     "ctl_invalid_model": ("/v1/chat/completions", {"model": "no-such-model", "messages": [{"role": "user", "content": "hi"}], "user": m}),
     "ctl_provider_4xx": ("/v1/chat/completions", {"model": "chat-openai", "max_completion_tokens": -5, "messages": [{"role": "user", "content": "hi"}], "user": m}),
    }
def counts(scope, call_id):
    cur.execute("select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like %s or payload::text like %s", (f"%{scope}%", f"%{call_id or '-'}%")); ev = cur.fetchone()[0]
    cur.execute("select count(*) from \"LiteLLM_AccountingDelivery\" d join \"LiteLLM_AccountingEvent\" e on e.event_id=d.event_id where e.payload::text like %s or e.payload::text like %s", (f"%{scope}%", f"%{call_id or '-'}%")); dl = cur.fetchone()[0]
    cur.execute("select call_type, status, model, spend from \"LiteLLM_SpendLogs\" where end_user=%s or request_id=%s or metadata::text like %s", (scope, call_id or "-", f"%{call_id or scope}%")); sl = cur.fetchall()
    return ev, dl, [list(r) for r in sl]
res = {"url": url, "db": db, "cases": {}}
for name, (path, body) in cases("x").items():
    m = f"t5d2-{name}-{uuid.uuid4().hex[:8]}"; path, body = cases(m)[name]
    lines0 = sum(1 for _ in open(log, errors="ignore"))
    t0 = time.time(); r = c.post(path, json=body); dt = round((time.time() - t0) * 1000)
    call_id = r.headers.get("x-litellm-call-id"); ev0, dl0, _ = counts(m, call_id)
    time.sleep(5); ev, dl, sl = counts(m, call_id)
    time.sleep(11); _, _, sl = counts(m, call_id)
    new = open(log, errors="ignore").read().splitlines()[lines0:]; tb = sum(1 for l in new if "Traceback" in l); capfail = sum(1 for l in new if "Usage capture failed" in l)
    err = r.text[:150] if r.status_code >= 400 else ""
    res["cases"][name] = {"scope": m, "status": r.status_code, "ms": dt, "call_id": call_id, "events_at_resp": ev0, "events_after_5s": ev, "deliveries_after_5s": dl, "spendlogs": sl, "new_log_tracebacks": tb, "capture_failed_lines": capfail, "error": err}
    print(f"{name:22s} http={r.status_code} ev@resp={ev0} ev@5s={ev} deliv={dl} tb={tb} capfail={capfail} spendlogs={[(s[0],s[1]) for s in sl]} {err[:90]}")
json.dump(res, open(out, "w"), indent=1, default=str)
