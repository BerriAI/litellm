import os, sys, urllib.parse as u
p = u.urlparse(os.environ["DATABASE_URL"]); port = os.environ.get("PG_PORT_OVERRIDE"); netloc = p.netloc.rsplit(":",1)[0] + ":" + port if port else p.netloc; print(p._replace(path="/" + sys.argv[1], netloc=netloc).geturl())
