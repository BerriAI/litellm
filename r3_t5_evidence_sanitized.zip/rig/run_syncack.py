"""D2: sync-ack supported/unsupported routes against a proxy; checks commit-before-response and no provider dispatch for 400s."""
import json, sys, time, uuid, subprocess, httpx, psycopg2
url, db, out = sys.argv[1], sys.argv[2], sys.argv[3]
m = f"t5sync-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
c = httpx.Client(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=60)
cases = {
 "chat": ("/v1/chat/completions", {"model": "chat-openai", "messages": [{"role": "user", "content": "hi"}], "user": f"{m}-chat"}),
 "text": ("/v1/completions", {"model": "chat-openai", "prompt": "hi", "max_tokens": 5, "user": f"{m}-text"}),
 "embed": ("/v1/embeddings", {"model": "embed", "input": "hi", "user": f"{m}-embed"}),
 "responses": ("/v1/responses", {"model": "chat-openai", "input": "hi", "user": f"{m}-responses"}),
 "stream_unsupported": ("/v1/chat/completions", {"model": "chat-openai", "stream": True, "messages": [{"role": "user", "content": "hi"}], "user": f"{m}-stream"}),
 "background_unsupported": ("/v1/responses", {"model": "chat-openai", "input": "hi", "background": True, "user": f"{m}-bg"}),
 "ocr_unsupported": ("/v1/ocr", {"model": "ocr", "document": {"type": "document_url", "document_url": "https://arxiv.org/pdf/1706.03762v7"}, "pages": [0]}),
 "anthropic_unsupported": ("/v1/messages", {"model": "chat-anthropic", "max_tokens": 5, "messages": [{"role": "user", "content": "hi"}], "metadata": {"user_id": f"{m}-am"}}),
}
res = {"marker": m, "cases": {}}
for name, (path, body) in cases.items():
    t0 = time.time(); r = c.post(path, json=body); dt = time.time() - t0
    call_id = r.headers.get("x-litellm-call-id"); scope = body.get("user") or (body.get("metadata") or {}).get("user_id") or call_id or "-"
    cur.execute("select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like %s or payload::text like %s", (f"%{scope}%", f"%{call_id or '-'}%"))
    immediate = cur.fetchone()[0]
    time.sleep(1.5)
    cur.execute("select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like %s or payload::text like %s", (f"%{scope}%", f"%{call_id or '-'}%")); later = cur.fetchone()[0]
    err = r.text[:160] if r.status_code >= 400 else ""
    res["cases"][name] = {"status": r.status_code, "ms": round(dt * 1000), "events_at_response": immediate, "events_after_1.5s": later, "call_id": call_id, "error": err}
    print(f"{name:24s} http={r.status_code} {round(dt*1000)}ms events@resp={immediate} events@+1.5s={later} {err}")
json.dump(res, open(out, "w"), indent=1)
