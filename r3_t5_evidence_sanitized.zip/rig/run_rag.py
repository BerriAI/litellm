"""Gate 2 RAG multi-round: vector store built directly at OpenAI, then /v1/rag/query through the proxy; inspect parent/child ownership."""
import io, json, os, sys, time, uuid, subprocess, httpx, psycopg2
url, db, out = sys.argv[1], sys.argv[2], sys.argv[3]; m = f"t5rag-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
oa = httpx.Client(base_url="https://api.openai.com/v1", headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"}, timeout=120)
f = oa.post("/files", files={"file": ("t5notes.txt", io.BytesIO(b"The T5 verification marker fruit is a purple mango. The secret number is 4471."), "text/plain")}, data={"purpose": "assistants"}); fid = f.json()["id"]
vs = oa.post("/vector_stores", json={"name": m, "file_ids": [fid]}); vsid = vs.json()["id"]
for _ in range(30):
    if (oa.get(f"/vector_stores/{vsid}").json().get("file_counts") or {}).get("completed", 0) >= 1: break
    time.sleep(2)
c = httpx.Client(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=180); t0 = time.time()
r = c.post("/v1/rag/query", json={"model": "chat-openai", "messages": [{"role": "user", "content": "What is the secret number and the marker fruit?"}], "retrieval_config": {"vector_store_id": vsid, "custom_llm_provider": "openai", "top_k": 3}, "user": f"{m}-q"}); ms = round((time.time() - t0) * 1000)
cid = r.headers.get("x-litellm-call-id"); print("rag", r.status_code, ms, "ms call_id", cid, r.text[:220]); time.sleep(8)
cur.execute("select kind::text, payload->'event'->>'call_type', left(event_id,46), payload->>'ownership', payload->>'charge_eligible', payload->>'request_count_eligible', payload->>'usage_source', payload->'usage'->>'total_tokens', payload->>'finalized_cost' is not null, left(coalesce(payload->>'parent_request_id',''),12), payload->>'model' from \"LiteLLM_AccountingEvent\" where payload::text like %s or (%s <> '' and payload::text like %s) order by recorded_at", (f"%{m}-q%", cid or "", f"%{cid}%")); evs = [list(x) for x in cur.fetchall()]
time.sleep(12); cur.execute("select left(request_id,30), call_type, status, model, spend, total_tokens from \"LiteLLM_SpendLogs\" where end_user=%s or metadata::text like %s or request_id=%s", (f"{m}-q", f"%{m}-q%", cid or "-")); rows = [list(x) for x in cur.fetchall()]
[print("  ev", json.dumps(e, default=str)[:230]) for e in evs]; print("  spendlogs", rows)
oa.delete(f"/vector_stores/{vsid}"); oa.delete(f"/files/{fid}")
json.dump({"marker": m, "vector_store": vsid, "call_id": cid, "rag_status": r.status_code, "ms": ms, "rag_body": r.text[:600], "events": evs, "spendlogs": rows}, open(out, "w"), indent=1, default=str)
