create table if not exists t5_txn_probe (txid bigint, event_id text, at timestamptz default clock_timestamp());
create or replace function t5_probe() returns trigger language plpgsql as $$ begin insert into t5_txn_probe(txid, event_id) values (txid_current(), new.event_id); return new; end $$;
drop trigger if exists t5_probe_trg on "LiteLLM_AccountingEvent";
create trigger t5_probe_trg after insert on "LiteLLM_AccountingEvent" for each row execute function t5_probe();
