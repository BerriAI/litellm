"""Group 10: N requests at concurrency C; latency p50/p95, proxy RSS before/after, pg xact_commit delta, events written."""
import asyncio, json, os, sys, time, uuid, subprocess, httpx, psycopg2, statistics
url, db, pidfile, out = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
N, C = int(os.environ.get("N", 80)), int(os.environ.get("C", 10))
m = f"t5load-{uuid.uuid4().hex[:6]}"; pid = int(open(pidfile).read().strip())
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
def rss(): return int(open(f"/proc/{pid}/status").read().split("VmRSS:")[1].split()[0]) // 1024
def xacts(): cur.execute("select xact_commit from pg_stat_database where datname=%s", (db,)); return cur.fetchone()[0]
def nevents(): cur.execute("select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like %s", (f"%{m}%",)); return cur.fetchone()[0]
async def main():
    sem = asyncio.Semaphore(C); lat = []; codes = {}
    async with httpx.AsyncClient(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=120) as c:
        async def one(i):
            async with sem:
                t0 = time.perf_counter(); r = await c.post("/v1/chat/completions", json={"model": "chat-openai", "messages": [{"role": "user", "content": "say ok"}], "max_completion_tokens": 50, "user": f"{m}-{i}"}); lat.append(time.perf_counter() - t0); codes[r.status_code] = codes.get(r.status_code, 0) + 1
        rss0, x0, t0 = rss(), xacts(), time.time()
        await asyncio.gather(*(one(i) for i in range(N)))
        wall = time.time() - t0
    ev = 0
    for _ in range(60):
        ev = nevents()
        if ev >= 2 * N: break
        await asyncio.sleep(1)
    rss1, x1 = rss(), xacts()
    res = {"marker": m, "n": N, "c": C, "codes": codes, "wall_s": round(wall, 1), "p50_ms": round(statistics.median(lat) * 1000), "p95_ms": round(sorted(lat)[int(0.95 * len(lat)) - 1] * 1000), "rss_mb_before": rss0, "rss_mb_after": rss1, "xact_commit_delta": x1 - x0, "events": ev}
    print(json.dumps(res)); json.dump(res, open(out, "w"), indent=1)
asyncio.run(main())
