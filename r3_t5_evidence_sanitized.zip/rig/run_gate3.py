"""Gate 3 reachable cases on one capture-on proxy: Gemini sync/stream/PDF, post-call guardrail failure (non-stream + stream), realtime websocket, MCP via Responses, OpenAI batch."""
import asyncio, io, json, os, sys, time, uuid, subprocess, httpx, psycopg2
url, db, out = sys.argv[1], sys.argv[2], sys.argv[3]; only = set(sys.argv[4].split(",")) if len(sys.argv) > 4 else None
m = f"t5g3-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
H = {"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}; c = httpx.Client(base_url=url, headers=H, timeout=180); res = {"marker": m, "cases": {}}
def ev(scope, wait=15):
    for _ in range(wait):
        cur.execute("select kind::text, payload->'event'->>'outcome', payload->>'usage_source', payload->'event'->'metrics', payload->'usage', payload->'pricing'->>'reported_cost', payload->>'phase', left(payload->>'job_id',30), payload->>'parent_request_id', payload->>'ownership', event_id from \"LiteLLM_AccountingEvent\" where payload::text like %s order by kind, recorded_at", (f"%{scope}%",)); rows = cur.fetchall()
        if rows: return [list(r) for r in rows]
        time.sleep(1)
    return []
def sl(scope):
    cur.execute("select call_type, status, model, spend, total_tokens, prompt_tokens, completion_tokens from \"LiteLLM_SpendLogs\" where end_user=%s or metadata::text like %s", (scope, f"%{scope}%")); return [list(r) for r in cur.fetchall()]
def rec(name, status, scope, extra=None, wait=15):
    e = ev(scope, wait); time.sleep(0.5); entry = {"scope": scope, "status": status, "events": e, **(extra or {})}; res["cases"][name] = entry
    print(f"\n## {name} http={status} {json.dumps(extra or {}, default=str)[:300]}")
    for x in e: print("   ev", json.dumps(x, default=str)[:330])
def want(n): return only is None or n in only
if want("gemini"):
    for sub, body in (("sync", {"stream": False}), ("stream", {"stream": True, "stream_options": {"include_usage": True}})):
        s = f"{m}-gem{sub}"; r = c.post("/v1/chat/completions", json={"model": "gemini", "messages": [{"role": "user", "content": "Say hello in five words."}], "user": s, **body})
        usage = None; text = ""
        if body["stream"]:
            for line in r.text.splitlines():
                if line.startswith("data:") and "[DONE]" not in line:
                    d = json.loads(line[5:]); usage = d.get("usage") or usage; text += "".join((ch.get("delta") or {}).get("content") or "" for ch in d.get("choices", []))
        else: usage = r.json().get("usage"); text = r.json()["choices"][0]["message"]["content"] if r.status_code == 200 else r.text[:200]
        rec(f"gemini_{sub}", r.status_code, s, {"usage": usage, "cost_hdr": r.headers.get("x-litellm-response-cost"), "text": text[:80], "err": r.text[:200] if r.status_code != 200 else None})
    s = f"{m}-gempdf"; r = c.post("/v1/chat/completions", json={"model": "gemini", "messages": [{"role": "user", "content": [{"type": "text", "text": "One sentence: what is this paper about?"}, {"type": "file", "file": {"file_id": "https://arxiv.org/pdf/1706.03762v7", "format": "application/pdf"}}]}], "user": s})
    rec("gemini_pdf", r.status_code, s, {"usage": r.json().get("usage") if r.status_code == 200 else None, "cost_hdr": r.headers.get("x-litellm-response-cost"), "err": r.text[:200] if r.status_code != 200 else None})
if want("guardrail"):
    s = f"{m}-gfail"; r = c.post("/v1/chat/completions", json={"model": "chat-openai", "messages": [{"role": "user", "content": "Say ok"}], "max_completion_tokens": 5, "user": s}); time.sleep(12)
    rec("guardrail_post_nonzero", r.status_code, s, {"body": r.text[:160], "spendlogs": sl(s)})
    s = f"{m}-stream-gfail"; r = c.post("/v1/chat/completions", json={"model": "chat-openai", "stream": True, "messages": [{"role": "user", "content": "Say ok"}], "max_completion_tokens": 5, "user": s}); time.sleep(12)
    rec("guardrail_post_stream", r.status_code, s, {"tail": r.text[-200:], "spendlogs": sl(s)})
    s = f"{m}-gok"; r = c.post("/v1/chat/completions", json={"model": "chat-openai", "messages": [{"role": "user", "content": "Say ok"}], "max_completion_tokens": 5, "user": s}); rec("guardrail_pass_control", r.status_code, s, {"cost_hdr": r.headers.get("x-litellm-response-cost")})
if want("mcp"):
    s = f"{m}-mcp"; r = c.post("/v1/responses", json={"model": "chat-openai", "input": "Use the add tool to add 2 and 3, reply with the number only.", "user": s, "tools": [{"type": "mcp", "server_label": "t5math", "server_url": "litellm_proxy", "require_approval": "never", "headers": {"x-litellm-api-key": "Bearer REDACTED_TEST_MASTER_KEY"}}]})
    body = r.json() if r.status_code == 200 else {}; types = [o.get("type") for o in body.get("output", [])]
    rec("mcp_responses", r.status_code, s, {"output_types": types, "usage": body.get("usage"), "cost_hdr": r.headers.get("x-litellm-response-cost"), "err": r.text[:300] if r.status_code != 200 else None, "spendlogs": sl(s)}, wait=20)
    r2 = c.post("/mcp/tools/call", json={"name": "t5math-add", "arguments": {"a": 4, "b": 5}}, headers={**H, "x-mcp-servers": "t5math"}); time.sleep(3)
    rec("mcp_direct_tool_call", r2.status_code, r2.headers.get("x-litellm-call-id") or "no-call-id", {"body": r2.text[:200]}, wait=5)
if want("realtime"):
    import websockets
    async def rt():
        s = f"{m}-rt"; got = []; wsurl = url.replace("http", "ws") + "/v1/realtime?model=realtime"
        async with websockets.connect(wsurl, additional_headers=H, max_size=None) as ws:
            await ws.send(json.dumps({"type": "session.update", "session": {"type": "realtime", "output_modalities": ["text"], "instructions": "Reply with one short sentence."}}))
            await ws.send(json.dumps({"type": "conversation.item.create", "item": {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "Say hello."}]}}))
            await ws.send(json.dumps({"type": "response.create", "response": {"output_modalities": ["text"]}}))
            t0 = time.time()
            while time.time() - t0 < 40:
                try: msg = json.loads(await asyncio.wait_for(ws.recv(), 15))
                except asyncio.TimeoutError: break
                got.append(msg.get("type"))
                if msg.get("type") == "response.done": usage = (msg.get("response") or {}).get("usage"); break
            else: usage = None
            await ws.send(json.dumps({"type": "conversation.item.create", "item": {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "Count slowly to fifty."}]}}))
            await ws.send(json.dumps({"type": "response.create", "response": {"output_modalities": ["text"]}})); await asyncio.sleep(1.5)
            await ws.send(json.dumps({"type": "response.cancel"})); await asyncio.sleep(1.5)
        return got, locals().get("usage")
    try: got, usage = asyncio.run(rt()); st = 101
    except Exception as e: got, usage, st = [f"ERR {type(e).__name__}: {str(e)[:200]}"], None, 0
    time.sleep(12); cur.execute("select call_type, status, model, spend, total_tokens from \"LiteLLM_SpendLogs\" where call_type like '%realtime%' order by \"startTime\" desc limit 3"); rows = [list(r) for r in cur.fetchall()]
    cur.execute("select kind::text, payload->'event'->>'outcome', payload->>'usage_source', payload->'event'->'metrics', payload->>'ownership', event_id from \"LiteLLM_AccountingEvent\" where payload->'event'->>'call_type' like '%realtime%' order by recorded_at desc limit 6"); evs = [list(r) for r in cur.fetchall()]
    res["cases"]["realtime"] = {"status": st, "event_types": got[:40], "usage": usage, "spendlogs_realtime": rows, "events_realtime": evs}
    print(f"\n## realtime st={st} types={got[:12]} usage={usage}\n   spendlogs={rows}"); [print("   ev", json.dumps(x, default=str)[:300]) for x in evs]
if want("batch"):
    s = f"{m}-batch"; lines = "\n".join(json.dumps({"custom_id": f"{s}-{i}", "method": "POST", "url": "/v1/chat/completions", "body": {"model": "gpt-5-mini", "messages": [{"role": "user", "content": "Say ok"}], "max_completion_tokens": 5}}) for i in range(2))
    f = c.post("/v1/files", files={"file": ("batch.jsonl", io.BytesIO(lines.encode()), "application/jsonl")}, data={"purpose": "batch", "custom_llm_provider": "openai"})
    fid = f.json().get("id"); b = c.post("/v1/batches", json={"input_file_id": fid, "endpoint": "/v1/chat/completions", "completion_window": "24h", "custom_llm_provider": "openai", "metadata": {"user": s}})
    bid = b.json().get("id"); st = b.json().get("status"); polls = 0; t0 = time.time()
    while st not in ("completed", "failed", "expired", "cancelled") and time.time() - t0 < 900:
        time.sleep(15); g = c.get(f"/v1/batches/{bid}?custom_llm_provider=openai"); st = g.json().get("status"); polls += 1
    g1 = c.get(f"/v1/batches/{bid}?custom_llm_provider=openai"); g2 = c.get(f"/v1/batches/{bid}?custom_llm_provider=openai"); time.sleep(20)
    cur.execute("select kind::text, payload->'event'->>'outcome', payload->>'usage_source', payload->'event'->'metrics', payload->>'phase', left(payload->>'job_id',30), payload->'pricing'->>'reported_cost', event_id from \"LiteLLM_AccountingEvent\" where payload::text like %s order by recorded_at", (f"%{bid}%",)); evs = [list(r) for r in cur.fetchall()]
    cur.execute("select call_type, status, model, spend, total_tokens from \"LiteLLM_SpendLogs\" where metadata::text like %s or request_id like %s", (f"%{bid}%", f"%{bid}%")); rows = [list(r) for r in cur.fetchall()]
    res["cases"]["batch"] = {"file": f.status_code, "create": b.status_code, "batch_id": bid, "terminal": st, "polls": polls, "elapsed_s": round(time.time() - t0), "retrieve_twice": [g1.status_code, g2.status_code], "events": evs, "spendlogs": rows, "err": (f.text[:200] if f.status_code != 200 else None) or (b.text[:200] if b.status_code != 200 else None)}
    print(f"\n## batch file={f.status_code} create={b.status_code} terminal={st} polls={polls} {round(time.time()-t0)}s\n   spendlogs={rows}"); [print("   ev", json.dumps(x, default=str)[:300]) for x in evs]
json.dump(res, open(out, "w"), indent=1, default=str)
