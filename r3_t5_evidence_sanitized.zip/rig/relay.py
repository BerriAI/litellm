"""TCP relay 127.0.0.1:<listen> -> 127.0.0.1:5432. Touch <ctl> to drop all connections and refuse new ones; remove it to restore."""
import asyncio, os, sys
LISTEN, CTL = int(sys.argv[1]), sys.argv[2]
conns = set()
async def pipe(r, w):
    try:
        while data := await r.read(65536): w.write(data); await w.drain()
    except Exception: pass
    finally:
        try: w.close()
        except Exception: pass
async def handle(cr, cw):
    if os.path.exists(CTL): cw.close(); return
    try: ur, uw = await asyncio.open_connection("127.0.0.1", 5432)
    except Exception: cw.close(); return
    conns.add((cw, uw))
    await asyncio.gather(pipe(cr, uw), pipe(ur, cw)); conns.discard((cw, uw))
async def watchdog():
    while True:
        if os.path.exists(CTL):
            for cw, uw in list(conns):
                for w in (cw, uw):
                    try: w.transport.abort()
                    except Exception: pass
            conns.clear()
        await asyncio.sleep(0.05)
async def main():
    srv = await asyncio.start_server(handle, "127.0.0.1", LISTEN); asyncio.create_task(watchdog())
    async with srv: await srv.serve_forever()
asyncio.run(main())
