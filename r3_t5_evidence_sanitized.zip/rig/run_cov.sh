#!/bin/bash
# usage: run_cov.sh <worktree> <base_sha> <tag>   -- mapped unit suites + tests/unit/accounting + real-PG ledger suite, branch coverage, diff-cover vs base
W=$1; BASE=$2; TAG=$3; A=/home/ubuntu/t5_verify/artifacts; cd $W || exit 1
MAPPED=$(git diff --name-only $BASE HEAD -- litellm enterprise | grep '\.py$' | while read f; do t="tests/unit/${f#litellm/}"; t="${t%/*}/test_${t##*/}"; [ -f "$t" ] && echo "$t"; done | sort -u)
[ -d tests/unit/accounting ] && MAPPED="$MAPPED tests/unit/accounting"
echo "HEAD=$(git rev-parse HEAD) BASE=$BASE py=$(.venv/bin/python -V) pytest=$(.venv/bin/python -m pytest --version 2>&1 | head -1) coverage=$(.venv/bin/python -m coverage --version | head -1) diff_cover=$(.venv/bin/python -m diff_cover.diff_cover_tool --version 2>&1 | head -1)" > $A/${TAG}_coverage_run.log
echo "CMD: .venv/bin/python -m pytest -n 8 -q -p no:cacheprovider --cov=litellm --cov-branch --cov-report=xml:$A/${TAG}_coverage.xml --cov-report=json:$A/${TAG}_coverage.json $MAPPED tests/integration/database/test_accounting_ledger.py" >> $A/${TAG}_coverage_run.log
.venv/bin/python -m pytest -n 8 -q -p no:cacheprovider --cov=litellm --cov-branch --cov-report=xml:$A/${TAG}_coverage.xml --cov-report=json:$A/${TAG}_coverage.json $MAPPED tests/integration/database/test_accounting_ledger.py >> $A/${TAG}_coverage_run.log 2>&1; echo "PYTEST_EXIT $?" >> $A/${TAG}_coverage_run.log
.venv/bin/python -m diff_cover.diff_cover_tool $A/${TAG}_coverage.xml --compare-branch=$BASE --json-report $A/${TAG}_diff_cover.json > $A/${TAG}_diff_cover.txt 2>&1
tail -1 $A/${TAG}_coverage_run.log | grep -v PYTEST; grep -E "passed|failed" $A/${TAG}_coverage_run.log | tail -1; grep -E "^Total|^Missing|^Coverage" $A/${TAG}_diff_cover.txt
