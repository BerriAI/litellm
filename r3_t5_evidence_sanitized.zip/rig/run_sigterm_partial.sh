#!/bin/bash
# SIGTERM drain: capture-on proxy with flush 5s; fire 10 requests; SIGTERM immediately; measure exit time; count events.
cd /home/ubuntu/t5_verify; A=/home/ubuntu/t5_verify; M=t5part-$(head -c3 /dev/urandom | xxd -p)
./rig/start_proxy.sh /home/ubuntu/repos/wt-head $A/rig/config_capture_slow.yaml 4318 t5_sigterm3 $A/artifacts/r3_proxy_sigterm_partial.log | tail -1
PID=$(cat artifacts/r3_proxy_sigterm_partial.log.pid)
for i in $(seq 1 10); do curl -s -o /dev/null -w "%{http_code} " -H "Authorization: Bearer REDACTED_TEST_MASTER_KEY" -H "Content-Type: application/json" http://127.0.0.1:4318/v1/chat/completions -d "{\"model\":\"chat-openai\",\"messages\":[{\"role\":\"user\",\"content\":\"ok\"}],\"max_completion_tokens\":5,\"user\":\"$M-$i\"}" & done; sleep 0.3; echo
T0=$(date +%s.%N); kill -TERM $PID; while kill -0 $PID 2>/dev/null; do sleep 0.1; done; T1=$(date +%s.%N)
echo "http codes above were printed by requests that finished; in-flight ones get killed"; echo "SIGTERM -> exit in $(python3 -c "print(round($T1-$T0,2))")s"
sleep 2; echo "events for marker after exit: $(psql "$(python3 rig/pgurl.py t5_sigterm3)" -tAc "select count(*) from \"LiteLLM_AccountingEvent\" where payload::text like '%$M-%'") (partial: requests in flight at SIGTERM)"
grep -iE "drain|shutdown|usage capture|accounting" artifacts/r3_proxy_sigterm_partial.log | grep -v "Applying\|└─\|migration" | sed 's/^.\{0,25\}//' | cut -c1-140 | sort | uniq -c | head -8
