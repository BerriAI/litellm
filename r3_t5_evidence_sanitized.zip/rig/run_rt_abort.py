"""Realtime interrupted work: start a long response then close the websocket abruptly; inspect legacy row + events."""
import asyncio, json, sys, time, subprocess, psycopg2, websockets
url, db = sys.argv[1], sys.argv[2]; H = {"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
cur.execute("select count(*) from \"LiteLLM_SpendLogs\" where call_type like '%realtime%'"); n0 = cur.fetchone()[0]
async def go():
    async with websockets.connect(url.replace("http", "ws") + "/v1/realtime?model=realtime", additional_headers=H, max_size=None) as ws:
        await ws.send(json.dumps({"type": "session.update", "session": {"type": "realtime", "output_modalities": ["text"]}}))
        await ws.send(json.dumps({"type": "conversation.item.create", "item": {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "Count slowly from one to two hundred, one number per line."}]}}))
        await ws.send(json.dumps({"type": "response.create", "response": {"output_modalities": ["text"]}}))
        deltas = 0; t0 = time.time()
        while time.time() - t0 < 6:
            msg = json.loads(await asyncio.wait_for(ws.recv(), 10))
            if msg.get("type") == "response.output_text.delta": deltas += 1
            if deltas >= 5: break
        await ws.close(code=1001)
        return deltas
try: d = asyncio.run(go())
except Exception as e: d = f"closed: {type(e).__name__}"
print("deltas before abort:", d); time.sleep(14)
cur.execute("select call_type, status, model, spend, total_tokens, prompt_tokens, completion_tokens from \"LiteLLM_SpendLogs\" where call_type like '%%realtime%%' order by \"startTime\" desc limit 1"); print("latest realtime spendlog:", cur.fetchall())
cur.execute("select kind::text, payload->'event'->>'outcome', payload->>'usage_source', payload->'event'->'metrics', payload->'pricing'->>'reported_cost' from \"LiteLLM_AccountingEvent\" where payload->'event'->>'call_type' like '%%realtime%%' order by recorded_at desc limit 2"); [print("  ev", json.dumps(list(r), default=str)[:300]) for r in cur.fetchall()]
