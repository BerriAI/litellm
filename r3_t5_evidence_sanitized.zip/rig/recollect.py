"""Re-query SpendLogs/accounting rows for a saved run (spend logs flush in batches) and print a compact table."""
import json, sys, importlib.util
spec = importlib.util.spec_from_file_location("rl", "/home/ubuntu/t5_verify/rig/run_legacy.py"); rl = importlib.util.module_from_spec(spec); spec.loader.exec_module(rl)
import psycopg2, subprocess
path, db = sys.argv[1], sys.argv[2]
d = json.load(open(path)); marker = d["marker"]
conn = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()); cur = conn.cursor()
for name, rec in d["cases"].items():
    call_id = (rec.get("headers") or {}).get("x-litellm-call-id")
    rows = rl.db_rows(cur, call_id, f"{marker}-{rl.SUFFIX[name]}" if rl.SUFFIX[name] else call_id or "-")
    rec.update(rows)
    sl = rows["spendlogs"]; ev = rows["accounting_events"]
    sl_s = ",".join(f"{r['call_type']}/{r['status']}/{r['model']}/spend={r['spend']}/tok={r['total_tokens']}" for r in sl) or "-"
    ev_s = ev if isinstance(ev, str) else ",".join(f"{e['kind']}:{len(e['deliveries'] or [])}d" for e in ev) or "-"
    print(f"{name:19s} http={rec.get('status')} cost_hdr={(rec.get('headers') or {}).get('x-litellm-response-cost')} usage={json.dumps(rec.get('usage'))[:70] if rec.get('usage') else None}\n    spendlogs[{len(sl)}]={sl_s}\n    events={ev_s}")
json.dump(d, open(path, "w"), indent=1, default=str)
