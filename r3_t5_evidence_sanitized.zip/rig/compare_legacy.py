"""Normalized legacy comparison: status, header presence, SpendLogs call_type/status/model, spend == litellm cost_per_token(usage) within tolerance, events count."""
import json, sys
import litellm
files = sys.argv[1:]
data = {f: json.load(open(f)) for f in files}
names = list(next(iter(data.values()))["cases"].keys())
def norm(rec):
    sl = rec.get("spendlogs") or []; h = rec.get("headers") or {}
    row = sl[0] if sl else {}
    return {"http": rec.get("status"), "cost_hdr": h.get("x-litellm-response-cost") is not None, "call_type": row.get("call_type"), "sl_status": row.get("status"), "model": row.get("model"), "n_sl": len(sl), "events": rec.get("accounting_events") if isinstance(rec.get("accounting_events"), str) else len(rec.get("accounting_events") or [])}
def price_ok(rec):
    sl = rec.get("spendlogs") or []
    if not sl or sl[0].get("status") != "success" or not rec.get("usage"): return "n/a"
    row = sl[0]; u = rec["usage"]; model = row["model"]
    pt = u.get("prompt_tokens", u.get("input_tokens", 0)) or 0; ct = u.get("completion_tokens", u.get("output_tokens", 0)) or 0
    if model.endswith("mistral-ocr-latest"): return "ocr(pages)"
    try:
        from litellm.types.utils import Usage
        exp = litellm.completion_cost(model=model, usage=Usage(prompt_tokens=pt, completion_tokens=ct, total_tokens=pt + ct), call_type="embedding" if "embedding" in model else "completion") if False else None
        pc, cc = litellm.cost_per_token(model=model, prompt_tokens=pt, completion_tokens=ct)
        exp = pc + cc
    except Exception as e: return f"err:{type(e).__name__}"
    sp = float(row.get("spend") or 0)
    return "match" if abs(sp - exp) <= max(1e-9, 0.02 * exp) else f"spend={sp} exp={exp}"
for n in names:
    rows = {f.split("/")[-1].replace(".json", ""): (norm(d["cases"][n]), price_ok(d["cases"][n])) for f, d in data.items()}
    base = next(iter(rows.values()))[0]
    same = all({k: v for k, v in r[0].items() if k != "events"} == {k: v for k, v in base.items() if k != "events"} for r in rows.values())
    print(f"{n:19s} parity={'SAME' if same else 'DIFF'} " + " | ".join(f"{k}: http={v[0]['http']} {v[0]['call_type']}/{v[0]['sl_status']}/{v[0]['model']} ev={v[0]['events']} price={v[1]}" for k, v in rows.items()))
