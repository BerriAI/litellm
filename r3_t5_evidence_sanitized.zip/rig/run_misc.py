"""Groups 6-9 (what the rig can reach): native Gemini usageMetadata, Gemini PDF document, background Responses terminal polling + repeated retrieval, client disconnect mid-stream."""
import json, sys, time, uuid, subprocess, httpx, psycopg2
url, db, out = sys.argv[1], sys.argv[2], sys.argv[3]; m = f"t5misc-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
c = httpx.Client(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=120); res = {"marker": m, "cases": {}}
def ev(scope, wait=12):
    for _ in range(wait):
        cur.execute("select kind::text, payload->'event'->>'outcome', payload->>'usage_source', payload->'event'->'metrics', payload->'usage', payload->'pricing'->>'reported_cost', payload->>'job_id', payload->>'ownership' from \"LiteLLM_AccountingEvent\" where payload::text like %s order by kind", (f"%{scope}%",)); rows = cur.fetchall()
        if rows: return [list(r) for r in rows]
        time.sleep(1)
    return []
def sl(scope):
    time.sleep(11); cur.execute("select call_type, status, spend, total_tokens, prompt_tokens, completion_tokens from \"LiteLLM_SpendLogs\" where end_user=%s or metadata::text like %s", (scope, f"%{scope}%")); return [list(r) for r in cur.fetchall()]
def rec(name, r, scope, extra=None):
    e = ev(scope); entry = {"status": r.status_code, "usage": (r.json().get("usage") if r.headers.get("content-type","").startswith("application/json") else None), "cost_hdr": r.headers.get("x-litellm-response-cost"), "events": e, **(extra or {})}
    res["cases"][name] = entry; print(name, r.status_code, "cost", entry["cost_hdr"], "usage", json.dumps(entry["usage"])[:120] if entry["usage"] else None); [print("   ev", json.dumps(x)[:260]) for x in e]
# 1 native gemini
r = c.post("/v1/chat/completions", json={"model": "gemini", "messages": [{"role": "user", "content": "Say hello in five words."}], "user": f"{m}-gem"}); rec("gemini_chat", r, f"{m}-gem")
# 2 gemini PDF document via file url (DOCUMENT modality)
r = c.post("/v1/chat/completions", json={"model": "gemini", "messages": [{"role": "user", "content": [{"type": "text", "text": "One sentence: what is this paper about?"}, {"type": "file", "file": {"file_id": "https://arxiv.org/pdf/1706.03762v7", "format": "application/pdf"}}]}], "user": f"{m}-pdf"}); rec("gemini_pdf", r, f"{m}-pdf", {"body": r.text[:200] if r.status_code != 200 else None})
# 3 background responses: create, poll terminal, retrieve twice
r = c.post("/v1/responses", json={"model": "chat-openai", "input": "Say ok.", "background": True, "user": f"{m}-bg"}); rid = r.json().get("id"); st = r.json().get("status"); polls = []
for _ in range(60):
    g = c.get(f"/v1/responses/{rid}"); st = g.json().get("status"); polls.append(st)
    if st in ("completed", "failed", "cancelled", "incomplete"): break
    time.sleep(2)
g2 = c.get(f"/v1/responses/{rid}"); time.sleep(3)
rec("background_responses", g2, rid, {"create_status": r.status_code, "terminal": st, "polls": len(polls), "events_by_scope_user": ev(f"{m}-bg", 3)})
# 4 client disconnect mid-stream
scope = f"{m}-disc"
with c.stream("POST", "/v1/chat/completions", json={"model": "chat-openai", "stream": True, "messages": [{"role": "user", "content": "Write 300 words about rivers."}], "user": scope}) as s:
    n = 0
    for line in s.iter_lines():
        if line.startswith("data:"): n += 1
        if n >= 3: break
time.sleep(3); e = ev(scope, 20); res["cases"]["client_disconnect_stream"] = {"chunks_read": n, "events": e, "spendlogs": sl(scope)}
print("client_disconnect_stream chunks", n); [print("   ev", json.dumps(x)[:260]) for x in e]; print("   spendlogs", res["cases"]["client_disconnect_stream"]["spendlogs"])
json.dump(res, open(out, "w"), indent=1, default=str)
