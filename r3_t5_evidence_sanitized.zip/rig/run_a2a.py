"""Gate 2 A2A: register local scripted agent, send 2 messages through /a2a/{id}/message/send, inspect ownership + caller counts."""
import json, sys, time, uuid, subprocess, httpx, psycopg2
url, db, out = sys.argv[1], sys.argv[2], sys.argv[3]; m = f"t5a2a-{uuid.uuid4().hex[:6]}"
cur = psycopg2.connect(subprocess.check_output(["python3", "/home/ubuntu/t5_verify/rig/pgurl.py", db], text=True).strip()).cursor(); cur.connection.autocommit = True
c = httpx.Client(base_url=url, headers={"Authorization": "Bearer REDACTED_TEST_MASTER_KEY"}, timeout=60)
card = httpx.get("http://127.0.0.1:4399/.well-known/agent-card.json").json()
reg = c.post("/v1/agents", json={"agent_name": m, "agent_card_params": card, "litellm_params": {"custom_llm_provider": "pydantic_ai_agents", "api_base": "http://127.0.0.1:4399"}})
aid = reg.json().get("agent_id") or reg.json().get("id"); print("register", reg.status_code, aid, reg.text[:160] if reg.status_code >= 400 else "")
res = []
for i in range(2):
    rid = str(uuid.uuid4()); t0 = time.time()
    r = c.post(f"/a2a/{aid}/message/send", json={"jsonrpc": "2.0", "id": rid, "method": "message/send", "params": {"message": {"role": "user", "parts": [{"kind": "text", "text": f"{m} round {i}"}], "messageId": uuid.uuid4().hex}}}, headers={"x-litellm-end-user": f"{m}-u"})
    res.append({"http": r.status_code, "ms": round((time.time() - t0) * 1000), "call_id": r.headers.get("x-litellm-call-id"), "body": r.text[:200]}); print("send", res[-1]["http"], res[-1]["ms"], "ms", res[-1]["call_id"], r.text[:120])
time.sleep(8); ids = [x["call_id"] for x in res if x["call_id"]]
cur.execute("select kind::text, payload->'event'->>'call_type', left(event_id,46), payload->>'ownership', payload->>'charge_eligible', payload->>'request_count_eligible', payload->>'usage_source', payload->'usage'->>'total_tokens', payload->>'model', left(payload->>'event_time',19) from \"LiteLLM_AccountingEvent\" where payload::text like %s or payload::text like any(%s) order by recorded_at", (f"%{m}%", [f"%{i}%" for i in ids] or ["%nomatch%"])); evs = [list(x) for x in cur.fetchall()]
time.sleep(12); cur.execute("select left(request_id,36), call_type, status, model, spend, total_tokens from \"LiteLLM_SpendLogs\" where request_id = any(%s) or metadata::text like %s", (ids or ["-"], f"%{m}%")); rows = [list(x) for x in cur.fetchall()]
[print("  ev", json.dumps(e, default=str)[:230]) for e in evs]; print("  spendlogs", rows)
json.dump({"marker": m, "agent_id": aid, "register": reg.status_code, "sends": res, "events": evs, "spendlogs": rows}, open(out, "w"), indent=1, default=str)
