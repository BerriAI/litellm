# T5 durable usage capture, round 3 acceptance evidence

Scope: verify the T5 stack in aggregation (foundation #49190 + capture #49133). No merge, no T6, no code changes, both PRs draft.

## Revisions
| role | SHA | base |
|---|---|---|
| baseline | ccc56d27adeeece2a1069bde587c76486ba9ab39 | main merge-base |
| foundation tip (#49190) | b368c432d03de80d5b6efc2dd6d6389c4d9c9b11 | ccc56d2 |
| capture tip (#49133) | a2fbb6d260a5a25076542e836d9eb398648e51c5 | b368c43 |
| previous combined head (round 2) | 384aba76b0e56bc80b786fe44ebc83a85c7236f8 | 9f58c0f |
| D2 reproduction head (round 2, before) | d98ab80452ad4f78aef830162aa72a32a902d3b8 | 9f58c0f |

`git diff 384aba76 a2fbb6d -- litellm enterprise` is empty: production sources, native sources, pricing and generated API types are identical to the round 2 head. Round 2 evidence carried forward below is marked (R2 @384aba76); everything else ran at the final tips in this round (R3).

## Provenance (artifacts/r3_provenance.txt)
Python 3.12.13 in all three isolated venvs (frozen `uv sync`), prisma 0.11.0, pytest 9.0.3, coverage 7.14.0, diff-cover 9.7.2. Native inputs identical across checkouts: litellm-rust tree hash f79882bd476bd617b9322af740f291ab5968df65, rust-toolchain a1598ccb, pyproject 6e9e75a5, uv.lock 8cd31eb0. Each checkout built its own extension (.so prefixes 0bc4ce75 base, 6a092441 foundation, cc8aad34 capture). Container image litellm-t5:a2fbb6d built from `git archive a2fbb6d` with the repo Dockerfile, Python 3.13.18 inside.

Rig: isolated Postgres DBs `t5_*` on the shared cluster (never stopped), outage via TCP relay 127.0.0.1:5499 toggled by a flag file, proxies 4301 base/off, 4302 head/off, 4303 head/on, 4304 head sync_ack fail_closed, 4305 relay-backed, 4330 container. All rigs under t5_verify/rig (not committed).

## Gate 1, final head refresh at a2fbb6d (all R3)
| case | result | measurement | artifact |
|---|---|---|---|
| 10 legacy scenarios, base vs head off vs head on (chat, stream, embeddings, responses, text completion, zero-cost, messages, OCR, invalid model, invalid params) | PASS | 10/10 `parity=SAME` on status, header presence, SpendLogs call_type/status/model, spend == cost_per_token(usage); head on adds exactly 1 inbound + 1 outbound event per request; nondeterministic provider token counts normalized | r3_legacy_{base_off,head_off,head_on}.json, r3_legacy_compare.txt |
| D2 unsupported sync_ack: stream chat, background Responses, OCR, Messages | PASS | each 400 with documented message, 0 AccountingEvent, 0 AccountingDelivery by request identity, 0 capture tracebacks after drain, no provider dispatch (SpendLogs api_base empty, 13-22 ms vs 1397 ms + api.openai.com for the control) | r3_d2_after_a2fbb6d.json, r3_proxy_head_sync.log |
| D2 before leg at d98ab80 | PASS (R2 @d98ab80, carried) | stream + messages wrote events, background + OCR logged `'IGNORE_THIS' is not a valid CallTypes` tracebacks | r2 artifacts |
| positive controls: chat, text completion, embeddings, Responses with sync_ack | PASS | 200, 2 events committed before the response boundary | r3_d2_after_a2fbb6d.json |
| invalid model, provider 4xx with sync_ack | PASS | 400, events captured (billed failure / unknown usage) | same |
| outage fail_closed | PASS | 503; receipt wait 3.0 s (configured 3 s); client total 11.46 s, remainder legacy exception path DB work during outage; admitted events committed after restore (0 at +25 s, 2 at +45 s, backoff), no second callback | r3_outage_*.json, r3_proxy_relay*.log |
| outage log policy | PASS | 200 in 3.61 s, 2 events after restore | same |
| outage async | PASS | 200 during outage, 2 events after restore, post-restore request 200 | same |
| accounting writer batching (txid trigger on AccountingEvent only, SpendLogs excluded) | PASS | 80 req / conc 10: 160 events in 35 accounting txns (batch min 2, max 12, avg 5.1); p50 1054 ms, p95 1491 ms vs baseline p50 1105 ms, p95 1456 ms; RSS 768-774 MB vs 765-771 MB | r3_load_head.json, r3_load_base.json, r3_batch_report.txt |
| bounded overload past max_pending_records | PASS (R2 @384aba76, carried) | queue capped at exactly max_pending_records, visible UsageCaptureError, no silent drop | r2 artifacts |
| crash async (kill -9 before flush) | PASS (documented loss window) | 200, 0 events after kill, 0 after restart, control request flushes 2 | r3_crash.log |
| crash sync_ack (kill -9 after ack) | PASS | 2 events survive, restart + 1 request = 4 events, distinct identities, no double apply | r3_crash.log |
| SIGTERM full drain | PASS | 10 x 200, exit 0.41 s, 20 events, graceful shutdown + final flush logged | r3_sigterm.log |
| SIGTERM partial (10 in flight) | PASS | in_flight_requests=10 at signal, all 200, exit 1.12 s, 20 events | r3_sigterm_partial.log |

## Gate 2, previously unverified live paths
| case | result | measurement | artifact |
|---|---|---|---|
| Vertex batch lifecycle | NOT RUN | service account lacks storage.buckets.list/create (403), no GCS bucket available; handler requires gcs_bucket_name | r3_gcs_bucket.txt (empty) |
| internal RAG multi-round (/v1/rag/query, OpenAI vector store) | PASS | 200, 2596 ms; 1 SpendLogs aquery success 126 tokens spend 0.00018025; events: parent inbound + parent measured attempt (126 tok, charge eligible) + 2 `included_in_parent` children (vector search unknown, included response) with charge_eligible=false and request_count_eligible=false; no duplicate billing or caller count | r3_rag.json |
| A2A multi-round (local scripted agent, /v1/agents + /a2a/{id}/message/send) | PASS | a2a-sdk 1.1.0 installed (optional extra); 2 sends 200; per send 1 inbound asend_message + 1 outbound attempt usage_source=unknown (agent emits no usage); SpendLogs 2 rows model a2a_agent/... spend 0; no duplicate caller counts, 0 tracebacks | r3_a2a.json, r3_proxy_head_on2.log |
| source-built container lifecycle | PASS | image from a2fbb6d, Python 3.13.18; capture on + migration applied, liveness in 22 s, 3 x 200, docker stop (SIGTERM) exit 0 in 0.50 s, 6 events for 3 requests committed before exit | r3_docker_lifecycle.log, r3_docker_container.log, r3_docker_build.log |
| native Google alias forms | PASS (unit only, R2 carried) | mapped unit tests + raw usage immutability assertions; no live alias emitter exists | tests in PR |
| Gemini 3.1-flash-lite sync/stream/PDF, post-response guardrail, realtime incl. interrupt, MCP ownership, OpenAI /v1/batches terminal, 4 startup rejections, Python 3.10 + 3.13 venvs | PASS (R2 @384aba76, carried; production identical) | see round 2 report | r2 artifacts |

## Gate 3, per-PR coverage (--branch, mapped unit suites + tests/unit/accounting + real-PG tests/integration/database/test_accounting_ledger.py)
| PR | diff | changed exec lines | missing | changed-line | artifact |
|---|---|---|---|---|---|
| foundation #49190 | ccc56d2..b368c43 | 206 | 2 | 99% | r3cov_fnd_coverage_run.log, r3cov_fnd_coverage.{xml,json}, r3cov_fnd_diff_cover.{txt,json} |
| capture #49133 | b368c43..a2fbb6d | 508 | 17 | 96% | r3cov_cap_coverage_run.log, r3cov_cap_coverage.{xml,json}, r3cov_cap_diff_cover.{txt,json} |
| focused D2 fix | d98ab80..384aba76 prod lines, measured in the a2fbb6d run | 6 | 0 | 100% | computed from r3cov_cap_coverage.json |

Tests: foundation 441 passed / 0 failed. Capture 3817 passed, 13 skipped, 15 failed; all 15 are in the round 1/2 known set (5 sentry env, 7 admin-mcp env, 3 responses sdk-retry) and fail identically on ccc56d2, 0 new failures.

Touched-function branch coverage (changed production files, from coverage.json): foundation accounting_ledger 34/36, exception_handler 80/96, usage_meter 31/36 (145/168 = 86% on whole files, most misses are pre-existing exception_handler branches outside the diff). Capture T5-owned files: usage_capture 50/56, proxy_track_cost_callback 124/150, cost_finalization 8/8, accounting/types 60/60, batch_utils 87/88. Repo-wide (reported separately, not a target): foundation run 20.7% lines, capture run 32.4% lines.

Uncovered lines, inspected:
- usage_meter 165 and 219 (the two defensive writer guards): 165 is the loop that fails still-queued batches after the shutdown deadline expires with the writer task cancelled; 219 skips a pending item whose future is already finished, reachable only if the deadline cancel and an in-flight commit finish the same item. Both are reachable only through a shutdown deadline race on a real event loop; the plan rules out private-state tests, so they stay uncovered and explained.
- capture misses: usage_capture 305, 571, 574, 594 (non-Logging object / non-capturable response guards), proxy_track_cost_callback 334-335, 339, 631 (failure-path without logging object), batch_utils 325-327 (mixed-model batch branch), litellm_logging 2675, 2869, 6983, realtime_streaming 545, responses/main 437, 514 (background Responses terminal polling branches exercised live in R2 but not by the unit suites).
No lines excluded, thresholds unchanged, no suppressions, no simulated-SQL duplicates.

## Defects vs gaps
Confirmed T5 code defects at a2fbb6d: none.

Observations, not defects (judgment calls): MCP list/call rounds each count as an inbound request (same as legacy); batch create/poll events are `measured` with 0 tokens not `unknown`; a 503'd fail_closed request keeps a legacy SpendLogs failure row with spend while the durable event is succeeded; fail_closed 503 can exceed the ack timeout by ~8 s of legacy exception-path DB work during an outage (pre-existing).

Pre-existing issues observed outside T5: `/v1/files` through the proxy needs `files_settings`; vector store retrieve logs `ValueError: 'avector_store_retrieve' is not a valid CallTypes`; A2A route returns no x-litellm-call-id header; a2a-sdk is an optional extra not in the default sync.

Gaps (NOT RUN): Vertex batch (no GCS permission). Gemini raw usageMetadata alias forms unit only.

## Cleanup
Disposable proxies, relay, scripted agent, container, image and t5_* databases removed after this bundle was written; worktrees wt-base/wt-fnd/wt-head and their venvs retained for a possible rerun.
