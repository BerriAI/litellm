---
name: test-skill-litellm
description: A test skill created by LiteLLM automated tests
---

# Test Skill

This is a minimal test skill created for automated testing purposes.

